const express = require('express');
const { pool, withTransaction } = require('../db');
const { only } = require('../auth');
const { AppError, wrap, parseId, parseMoney, toCents, code, getSessionDetail } = require('../utils');

const router = express.Router();

// Recent transactions (both roles can read)
router.get('/', wrap(async (req, res) => {
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 50, 1), 500);
  const [rows] = await pool.query(
    `SELECT t.id, t.session_id, t.amount, t.payment_method, t.payment_amount, t.change_amount, t.transaction_date,
            c.computer_name, cu.customer_code, CONCAT(cu.first_name, ' ', cu.last_name) AS customer_name, s.guest_name, u.username AS processed_by
       FROM transactions t
       JOIN sessions s ON s.id = t.session_id
       JOIN computers c ON c.id = s.computer_id
       JOIN users u ON u.id = t.processed_by
       LEFT JOIN customers cu ON cu.id = t.customer_id
      ORDER BY t.transaction_date DESC, t.id DESC LIMIT ?`, [limit]);
  res.json(rows.map(r => ({
    id: r.id,
    code: code('PAY', r.id, 4),
    sessionId: r.session_id,
    sessionCode: code('SES', r.session_id, 4),
    computerName: r.computer_name,
    customerName: r.customer_name || (r.guest_name ? `${r.guest_name} (Guest)` : 'Guest'),
    customerCode: r.customer_code || null,
    amount: r.amount,
    method: r.payment_method,
    received: r.payment_amount,
    change: r.change_amount,
    date: r.transaction_date,
    processedBy: r.processed_by
  })));
}));

// Record payment for a COMPLETED session (cashier only).
// The billed amount comes from the database - the client only says how much cash was received.
router.post('/', only('cashier'), wrap(async (req, res) => {
  const sessionId = parseId(req.body.sessionId, 'session');
  const method = req.body.paymentMethod;
  if (!['Cash', 'GCash', 'Card'].includes(method)) throw new AppError(400, 'Choose Cash, GCash or Card.');
  const received = parseMoney(req.body.paymentAmount, 'Amount received');

  await withTransaction(async conn => {
    const [rows] = await conn.query('SELECT id, customer_id, status, total_amount FROM sessions WHERE id = ? FOR UPDATE', [sessionId]);
    const s = rows[0];
    if (!s) throw new AppError(404, 'Session not found.');
    if (s.status !== 'Completed') throw new AppError(409, 'End the session before collecting payment.');
    const [paid] = await conn.query('SELECT id FROM transactions WHERE session_id = ?', [sessionId]);
    if (paid.length) throw new AppError(409, 'This session has already been paid.');

    const dueC = toCents(s.total_amount);
    const recvC = toCents(received);
    if (recvC < dueC) throw new AppError(400, 'Amount received is less than the total bill.');
    if (method !== 'Cash' && recvC !== dueC) throw new AppError(400, 'GCash/Card payments must be the exact bill amount.');

    await conn.query(
      `INSERT INTO transactions (session_id, customer_id, processed_by, amount, payment_method, payment_amount, change_amount, transaction_date)
       VALUES (?, ?, ?, ?, ?, ?, ?, UTC_TIMESTAMP())`,
      [sessionId, s.customer_id, req.user.id, dueC / 100, method, recvC / 100, (recvC - dueC) / 100]);
  });
  res.status(201).json(await getSessionDetail(pool, sessionId));
}));

module.exports = router;
