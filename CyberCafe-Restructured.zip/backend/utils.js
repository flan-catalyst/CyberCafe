// Shared helpers: errors, validation, money math, and row -> JSON mappers.
class AppError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}

const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

// ---- money: all billing math is done in integer cents to avoid floating point errors
const toCents = v => Math.round(Number(v) * 100);
// Sessions ended before 30 minutes are charged half of the PC's hourly rate,
// rounded DOWN to a whole peso (e.g. ₱15/hour -> ₱7). From 30 minutes onward,
// the normal per-second prorated hourly calculation applies.
const rentalCents = (seconds, hourlyRate) => {
  const rateCents = toCents(hourlyRate);
  if (Number(seconds) < 1800) return Math.floor(rateCents / 200) * 100;
  return Math.round((Number(seconds) * rateCents) / 3600);
};

const code = (prefix, id, pad) => `${prefix}-${String(id).padStart(pad, '0')}`;

// ---- validation
function parseId(v, label = 'ID') {
  const n = Number(v);
  if (v === '' || v === null || v === undefined || !Number.isInteger(n) || n <= 0) {
    throw new AppError(400, `Invalid ${label}.`);
  }
  return n;
}

function cleanStr(v, { max = 100, required = false, label = 'Value' } = {}) {
  if (v === undefined || v === null) {
    if (required) throw new AppError(400, `${label} is required.`);
    return null;
  }
  if (typeof v !== 'string') throw new AppError(400, `${label} must be text.`);
  const s = v.trim();
  if (!s) {
    if (required) throw new AppError(400, `${label} is required.`);
    return null;
  }
  if (s.length > max) throw new AppError(400, `${label} must be ${max} characters or fewer.`);
  return s;
}

function parseMoney(v, label = 'Amount') {
  if (v === '' || v === null || v === undefined || typeof v === 'boolean') {
    throw new AppError(400, `${label} is required.`);
  }
  const n = typeof v === 'string' ? Number(v) : v;
  if (typeof n !== 'number' || !Number.isFinite(n) || n < 0 || n > 1000000) {
    throw new AppError(400, `${label} is not a valid amount.`);
  }
  if (Math.abs(n * 100 - Math.round(n * 100)) > 1e-6) {
    throw new AppError(400, `${label} can have at most 2 decimal places.`);
  }
  return n;
}

// ---- sessions
const SESSION_SELECT = `
  SELECT s.id, s.computer_id, c.computer_name, s.customer_id, cu.customer_code,
         CASE WHEN cu.id IS NULL THEN NULL ELSE CONCAT(cu.first_name, ' ', cu.last_name) END AS customer_name,
         s.guest_name, s.start_time, s.end_time, s.timer_mode, s.duration_limit_seconds, s.expires_at,
         s.duration_seconds, TIMESTAMPDIFF(SECOND, s.start_time, UTC_TIMESTAMP()) AS elapsed_seconds,
         CASE WHEN s.expires_at IS NULL THEN NULL ELSE TIMESTAMPDIFF(SECOND, UTC_TIMESTAMP(), s.expires_at) END AS remaining_seconds,
         s.hourly_rate, s.rental_amount, s.services_amount, s.additional_fee_amount, s.additional_fee_note, s.total_amount, s.status, s.end_reason,
         t.id AS tx_id, t.payment_method, t.payment_amount, t.change_amount, t.transaction_date
  FROM sessions s
  JOIN computers c ON c.id = s.computer_id
  LEFT JOIN customers cu ON cu.id = s.customer_id
  LEFT JOIN transactions t ON t.session_id = s.id`;

function mapSession(r) {
  const active = r.status === 'Active';
  const duration = active ? Math.max(0, r.elapsed_seconds) : r.duration_seconds;
  const rental = active ? rentalCents(duration, r.hourly_rate) / 100 : r.rental_amount;
  return {
    id: r.id,
    code: code('SES', r.id, 4),
    computerId: r.computer_id,
    computerName: r.computer_name,
    customerId: r.customer_id,
    customerCode: r.customer_code || null,
    customerName: r.customer_name || (r.guest_name ? `${r.guest_name} (Guest)` : 'Guest'),
    isGuest: !r.customer_id,
    guestName: r.guest_name,
    start: r.start_time,
    end: r.end_time,
    durationSeconds: duration,
    timerMode: r.timer_mode,
    durationLimitSeconds: r.duration_limit_seconds,
    expiresAt: r.expires_at,
    remainingSeconds: active && r.remaining_seconds !== null ? Math.max(0, r.remaining_seconds) : null,
    rate: r.hourly_rate,
    rentalAmount: rental,
    servicesAmount: r.services_amount || 0,
    additionalFeeAmount: active ? 0 : (r.additional_fee_amount || 0),
    additionalFeeNote: r.additional_fee_note || '',
    totalAmount: active ? rental + Number(r.services_amount || 0) : r.total_amount,
    status: r.status,
    endReason: r.end_reason || null,
    paid: !!r.tx_id,
    transaction: r.tx_id ? {
      id: r.tx_id,
      code: code('PAY', r.tx_id, 4),
      method: r.payment_method,
      received: r.payment_amount,
      change: r.change_amount,
      date: r.transaction_date
    } : null
  };
}

async function getSessionDetail(db, id) {
  const [rows] = await db.query(`${SESSION_SELECT} WHERE s.id = ?`, [id]);
  if (!rows.length) throw new AppError(404, 'Session not found.');
  const session = mapSession(rows[0]);
  const [lines] = await db.query(
    `SELECT ss.service_id, sv.name, ss.quantity, ss.unit_price
       FROM session_services ss JOIN services sv ON sv.id = ss.service_id
      WHERE ss.session_id = ? ORDER BY ss.id`, [id]);
  session.services = lines.map(l => ({
    serviceId: l.service_id,
    name: l.name,
    quantity: l.quantity,
    unitPrice: l.unit_price,
    lineTotal: toCents(l.unit_price) * l.quantity / 100
  }));
  return session;
}

// ---- customers
const CUSTOMER_SELECT = `
  SELECT cu.id, cu.customer_code, cu.first_name, cu.last_name, CONCAT(cu.first_name, ' ', cu.last_name) AS name, cu.contact, cu.email, cu.created_at,
    (SELECT COUNT(*) FROM sessions s WHERE s.customer_id = cu.id AND s.status = 'Active') AS active_sessions,
    (SELECT COUNT(*) FROM sessions s WHERE s.customer_id = cu.id AND s.status = 'Completed') AS completed_sessions,
    (SELECT COALESCE(SUM(s.total_amount), 0) FROM sessions s WHERE s.customer_id = cu.id AND s.status = 'Completed') AS total_spent
  FROM customers cu`;

const mapCustomer = r => ({
  id: r.id,
  code: r.customer_code,
  firstName: r.first_name,
  lastName: r.last_name,
  name: r.name,
  contact: r.contact || '',
  email: r.email || '',
  createdAt: r.created_at,
  activeSessions: r.active_sessions,
  completedSessions: r.completed_sessions,
  totalSpent: r.total_spent
});

module.exports = {
  AppError, wrap, toCents, rentalCents, code, parseId, cleanStr, parseMoney,
  SESSION_SELECT, mapSession, getSessionDetail, CUSTOMER_SELECT, mapCustomer
};
