// CyberCafe - Session & Billing System : Express API + static frontend
const path = require('path');
const express = require('express');
const session = require('express-session');
const config = require('./config');
const { pool } = require('./db');
const { auth, ensureDefaultUsers } = require('./auth');
const { AppError, rentalCents } = require('./utils');


async function migrateSchema() {
  // Keep older installations usable while moving the live database to the new schema.
  const hasColumn = async (table, column) => {
    const [r] = await pool.query(`SELECT COUNT(*) AS n FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?`, [table, column]);
    return Number(r[0].n) > 0;
  };
  if (!(await hasColumn('customers', 'first_name'))) await pool.query("ALTER TABLE customers ADD COLUMN first_name VARCHAR(60) NULL AFTER customer_code");
  if (!(await hasColumn('customers', 'last_name'))) await pool.query("ALTER TABLE customers ADD COLUMN last_name VARCHAR(60) NULL AFTER first_name");
  if (await hasColumn('customers', 'name')) {
    await pool.query("UPDATE customers SET first_name = COALESCE(NULLIF(first_name,''), SUBSTRING_INDEX(name,' ',1)), last_name = COALESCE(NULLIF(last_name,''), TRIM(SUBSTRING(name, LENGTH(SUBSTRING_INDEX(name,' ',1)) + 1))) WHERE first_name IS NULL OR last_name IS NULL OR first_name='' OR last_name=''");
    await pool.query("ALTER TABLE customers MODIFY first_name VARCHAR(60) NOT NULL, MODIFY last_name VARCHAR(60) NOT NULL");
    const [nameIdx] = await pool.query("SELECT COUNT(*) AS n FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'customers' AND index_name = 'idx_customers_name'");
    if (Number(nameIdx[0].n)) await pool.query("ALTER TABLE customers DROP INDEX idx_customers_name");
    await pool.query("ALTER TABLE customers ADD KEY idx_customers_name (last_name, first_name)");
    await pool.query("ALTER TABLE customers DROP COLUMN name");
  } else {
    await pool.query("ALTER TABLE customers MODIFY first_name VARCHAR(60) NOT NULL, MODIFY last_name VARCHAR(60) NOT NULL");
  }
  if (!(await hasColumn('sessions', 'timer_mode'))) await pool.query("ALTER TABLE sessions ADD COLUMN timer_mode ENUM('open','fixed') NOT NULL DEFAULT 'open' AFTER end_time");
  if (!(await hasColumn('sessions', 'duration_limit_seconds'))) await pool.query("ALTER TABLE sessions ADD COLUMN duration_limit_seconds INT UNSIGNED NULL AFTER timer_mode");
  if (!(await hasColumn('sessions', 'expires_at'))) await pool.query("ALTER TABLE sessions ADD COLUMN expires_at DATETIME NULL AFTER duration_limit_seconds");
  if (!(await hasColumn('sessions', 'end_reason'))) await pool.query("ALTER TABLE sessions ADD COLUMN end_reason ENUM('Manual','Timeout') NULL AFTER status");
  if (!(await hasColumn('sessions', 'additional_fee_amount'))) await pool.query("ALTER TABLE sessions ADD COLUMN additional_fee_amount DECIMAL(10,2) NOT NULL DEFAULT 0 AFTER services_amount");
  if (!(await hasColumn('sessions', 'additional_fee_note'))) await pool.query("ALTER TABLE sessions ADD COLUMN additional_fee_note VARCHAR(200) NULL AFTER additional_fee_amount");
  // Remove the unwanted service options from the selectable list while preserving historical session line references.
  await pool.query("UPDATE services SET is_active = 0 WHERE LOWER(name) = 'laminate' OR (LOWER(name) LIKE '%pico%pc%wash%')");
  const [expIdx] = await pool.query("SELECT COUNT(*) AS n FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'sessions' AND index_name = 'idx_sessions_expiry'");
  if (!Number(expIdx[0].n)) await pool.query("ALTER TABLE sessions ADD KEY idx_sessions_expiry (status, expires_at)");
  // Extend the computer enum. The old unique name constraint is replaced by an active-only generated name.
  await pool.query("ALTER TABLE computers MODIFY status ENUM('Available','In Use','Maintenance','Archived') NOT NULL DEFAULT 'Available'");
  const [idx] = await pool.query("SELECT COUNT(*) AS n FROM information_schema.statistics WHERE table_schema = DATABASE() AND table_name = 'computers' AND index_name = 'uq_computers_name'");
  if (Number(idx[0].n)) await pool.query("ALTER TABLE computers DROP INDEX uq_computers_name");
  const [activeCol] = await pool.query("SELECT COUNT(*) AS n FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'computers' AND column_name = 'active_computer_name'");
  if (!Number(activeCol[0].n)) {
    await pool.query("ALTER TABLE computers ADD COLUMN active_computer_name VARCHAR(30) GENERATED ALWAYS AS (IF(status = 'Archived', NULL, computer_name)) STORED");
    await pool.query("ALTER TABLE computers ADD UNIQUE KEY uq_computers_active_name (active_computer_name)");
  }
}

async function autoTimeoutSessions() {
  try {
    const [rows] = await pool.query(`SELECT id, computer_id, start_time, expires_at, hourly_rate FROM sessions WHERE status = 'Active' AND expires_at IS NOT NULL AND expires_at <= UTC_TIMESTAMP() LIMIT 50`);
    for (const s of rows) {
      await require('./db').withTransaction(async conn => {
        const [locked] = await conn.query(`SELECT id, computer_id, start_time, expires_at, hourly_rate, status FROM sessions WHERE id = ? FOR UPDATE`, [s.id]);
        const x = locked[0];
        if (!x || x.status !== 'Active' || !x.expires_at) return;
        const secs = Math.max(0, Math.floor((new Date(x.expires_at).getTime() - new Date(x.start_time).getTime()) / 1000));
        const rental = rentalCents(secs, x.hourly_rate) / 100;
        await conn.query(`UPDATE sessions SET end_time = expires_at, duration_seconds = ?, rental_amount = ?, services_amount = 0, total_amount = ?, end_reason = 'Timeout', status = 'Completed' WHERE id = ? AND status = 'Active'`, [secs, rental, rental, x.id]);
        await conn.query("UPDATE computers SET status = 'Available' WHERE id = ? AND status = 'In Use'", [x.computer_id]);
      });
      console.log(`[timeout] Session SES-${String(s.id).padStart(4, '0')} timed out automatically.`);
    }
  } catch (err) { console.error('[timeout]', err.code || err.message); }
}

process.env.TZ = config.timeZone;
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '100kb' }));

app.use((req, res, next) => {
  res.set({
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    'Cache-Control': req.path.startsWith('/api') ? 'no-store' : 'no-cache'
  });
  next();
});

app.use(session({
  name: 'cybercafe.sid',
  secret: config.sessionSecret,
  resave: false,
  saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: 'lax', maxAge: 12 * 60 * 60 * 1000 }
}));

// ---------------------------------------------------------------- API routes
app.get('/api/health', async (req, res, next) => {
  try { await pool.query('SELECT 1'); res.json({ ok: true }); } catch (e) { next(e); }
});
app.use('/api/auth', require('./routes/auth'));
app.use('/api/customers', auth(), require('./routes/customers'));
app.use('/api/computers', auth(), require('./routes/computers'));
app.use('/api/services', auth(), require('./routes/services'));
app.use('/api/sessions', auth(), require('./routes/sessions'));
app.use('/api/transactions', auth(), require('./routes/transactions'));
app.use('/api/admin', auth('admin'), require('./routes/admin'));
app.use('/api/users', auth('admin'), require('./routes/users'));
app.use('/api', (req, res) => res.status(404).json({ error: 'API endpoint not found.' }));

// ------------------------------------------------------------------ frontend
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// ------------------------------------------------------------ error handling
const DB_DOWN = new Set(['ECONNREFUSED', 'ENOTFOUND', 'ETIMEDOUT', 'PROTOCOL_CONNECTION_LOST',
  'ER_ACCESS_DENIED_ERROR', 'ER_BAD_DB_ERROR', 'ER_NO_SUCH_TABLE', 'ECONNRESET', 'ER_CON_COUNT_ERROR']);

app.use((err, req, res, next) => { // eslint-disable-line no-unused-vars
  if (err instanceof AppError) return res.status(err.status).json({ error: err.message });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Invalid request body.' });
  if (err.code === 'ER_DUP_ENTRY') {
    const m = err.sqlMessage || '';
    if (m.includes('uq_one_active_session_per_pc')) return res.status(409).json({ error: 'That computer already has an active session.' });
    if (m.includes('uq_transaction_session')) return res.status(409).json({ error: 'This session has already been paid.' });
    if (m.includes('uq_users_username')) return res.status(409).json({ error: 'That username is already taken.' });
    if (m.includes('uq_computers_active_name') || m.includes('uq_computers_name')) return res.status(409).json({ error: 'That computer name is already in use. Archived computer names can be reused.' });
    if (m.includes('uq_services_name')) return res.status(409).json({ error: 'That service already exists.' });
    return res.status(409).json({ error: 'That record already exists.' });
  }
  if (DB_DOWN.has(err.code) || err.fatal) {
    console.error('[db]', err.code || err.message);
    return res.status(503).json({ error: 'The database is not available right now. Please check that MySQL is running and tell the owner.' });
  }
  console.error('[error]', err);
  res.status(500).json({ error: 'Something went wrong on the server.' });
});

// ------------------------------------------------------------------- startup
async function prepare() {
  try {
    await migrateSchema();
    const created = await ensureDefaultUsers();
    console.log(`[db] Connected to MySQL database "${config.db.database}"${created ? ' (starter accounts created)' : ''}.`);
  } catch (err) {
    console.error(`[db] Could not use the database yet (${err.code || err.message}).`);
    console.error('     Check backend/.env and that database/database.sql was run. Retrying in 10 seconds...');
    setTimeout(prepare, 10000);
  }
}

app.listen(config.port, config.host, () => {
  console.log(`CyberCafe is running:  http://localhost:${config.port}`);
  console.log('Other computers on the network: http://<this-computer-IP>:' + config.port);
  prepare();
  setInterval(autoTimeoutSessions, 2000);
});
