# CyberCafe – Session & Billing System (database-backed)

```
Browser (frontend)  ->  Express API (backend)  ->  MySQL (database)
 Cashier / Admin         Node.js, port 3000         cybercafe
```

## Folder structure
```
CyberCafe/
├── README.md
├── package.json
├── package-lock.json
├── server.js           (compatibility entry point)
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── script.js
├── backend/
│   ├── package.json
│   ├── .env.example    (copy to .env and edit)
│   ├── server.js       config.js   db.js   auth.js   utils.js
│   ├── smoke-test.js   (automated version of the 12 tests)
│   └── routes/  auth.js customers.js computers.js services.js sessions.js transactions.js admin.js users.js
└── database/
    └── database.sql  (includes assignment Section 3.3 query demonstration)
```

## Why Node.js + Express + MySQL
Your frontend is plain HTML/CSS/JavaScript (Bootstrap, fetch-friendly rendering). Express serves those same files
and a JSON API from ONE small program, so the cashier PC only needs Node.js + MySQL, there are no CORS problems,
and the JS you already have maps directly onto API calls. mysql2 gives prepared statements and transactions
(needed so two cashiers can never start the same PC twice).

## 1. Install the software (on the SERVER computer only)
1. **Node.js 20 LTS** – https://nodejs.org (install with defaults).
2. **MySQL Server 8.x + MySQL Workbench** – https://dev.mysql.com/downloads/ (remember the `root` password you set).

## 2. Create the database
1. Open MySQL Workbench and connect to your local server.
2. For a fresh database, File > Open SQL Script > choose `database/database.sql`.
3. Click the lightning-bolt **Execute** button. For an existing database, the backend automatically migrates the customer, computer-status, and session-timer columns when it starts, so do not drop your database.
4. (Recommended) Uncomment the `CREATE USER` block at the bottom of the file, run it, and use that user in `.env`.

## 2A. SQL query demonstration (assignment Section 3.3)

The Section 3.3 SQL query demonstration (SELECT, INSERT, UPDATE, DELETE, and an advanced query) is included at the end of `database/database.sql`; no separate query file is needed.
It demonstrates `SELECT`, `INSERT`, `UPDATE`, and `DELETE`, plus an advanced query combining `WHERE`, `GROUP BY`,
and `ORDER BY`. Each query has a short purpose note and expected-output note. The INSERT/UPDATE/DELETE sequence
uses only the dedicated `DEMO-SQL-001` test customer; the DELETE statement targets that test record only.

The services seed data includes five services, including Document Typing, to meet the minimum of five sample records
for the `services` main entity table. On a database that was already initialized, rerun `database/database.sql`
to insert the additional service; the seed statement is safe to rerun and does not duplicate service names.

## 3. Configure and start the backend
Open a terminal in the project folder (the folder containing this README):
```
npm install
copy backend\.env.example backend\.env        (Mac/Linux: cp backend/.env.example backend/.env)
```
Edit `backend\.env`: set `DB_PASSWORD` (and `DB_USER` if you made a dedicated user) and `SESSION_SECRET` (any long random text). Then, from the project folder, run:
```
npm start
```
You should see `CyberCafe is running: http://localhost:3000`. On the very first start the backend creates the two
starter staff accounts (passwords are stored hashed):

| Role    | Username  | Password     |
|---------|-----------|--------------|
| Admin   | `admin`   | `admin123`   |
| Cashier | `cashier` | `cashier123` |

**Change both passwords right after the first login** (Admin > Users & Roles > Reset Password).

## 4. Open the system
* On the server PC: http://localhost:3000
* On other PCs in the cafe: `http://<server-IP>:3000` (find the IP with `ipconfig`; allow Node.js / port 3000 through Windows Firewall when asked).
* Open the site through that address – do NOT double-click `index.html` (the API would not be reachable).
* The page loads Bootstrap and Chart.js from a CDN, so the PCs need internet access (same as your original frontend).

## 5. Testing
Automatic (server running in one window, a second window in `backend`):
```
npm test
```
It runs all 12 scenarios (customer, guest session, refresh persistence, duplicate rejection, billing, payment,
computer status, customer-linked session, history, admin stats, permissions, no customer login) and prints PASS/FAIL.
It leaves a few "TEST" rows behind, so run it BEFORE opening the cafe for real.

**Resetting test data:** in Workbench run `DROP DATABASE cybercafe;`, run `database.sql` again, restart the backend.

Manual quick check: sign in as `cashier`, Start Session (Guest) on PC-01 -> refresh the page (still In Use) ->
try to start PC-01 again (rejected) -> End Session -> Confirm Payment -> receipt; sign in as `admin` and look at the dashboard.

## What changed compared with the mock-up (decisions worth knowing)
* **Roles:** Admin = statistics, reports, computers (rate/status/add/remove), services, users. Admin has NO Start/End/Payment
  controls and the backend returns 403 if it tries. Cashier = customers, sessions, payments; read-only for everything else.
* **Computer statuses** are Available / In Use / Maintenance (the "Reserved" status was removed to match your spec).
* **Ending a session** frees the computer immediately and creates a bill; the app then opens "Collect Payment".
  If the cashier cancels that window, the bill stays *Pending* on the Billing page until paid.
* **Billing** = exact elapsed seconds x the PC rate that was active when the session started (+ services),
  rounded to the centavo, calculated and stored by the server. The running amount on screen is only an estimate.
* Services can be added when ending the session (as in your original); only admins can create new services.
* Dates and times are stored in UTC; the application displays Philippine time using `Asia/Manila` / UTC+08:00. `CAFE_TZ_OFFSET` controls report-day calculations.
* Staff logins last 12 hours and are lost if the backend restarts. Backups: use MySQL Workbench > Data Export regularly.


## Recent update

- Ended sessions are displayed as **Timed Out** in session/billing views; a successfully collected payment changes the billing status to **Paid**.
- Cashiers can enter an optional additional fee and description when ending a session. These values are stored on the `sessions` row (`additional_fee_amount`, `additional_fee_note`), so no extra table is required.
- The service migration deactivates the unwanted Laminate and Picos PC Wash service entries without deleting historical service records.
- Startup migration adds the additional-fee columns to existing databases automatically.
