const express = require('express');
const { pool, withTransaction } = require('../db');
const { only } = require('../auth');
const { AppError, wrap, parseId, cleanStr, code, SESSION_SELECT, mapSession, CUSTOMER_SELECT, mapCustomer } = require('../utils');

const router = express.Router();

// List / search customers (cashier + admin can read)
router.get('/', wrap(async (req, res) => {
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 100) : '';
  const like = `%${q.replace(/[\\%_]/g, m => '\\' + m)}%`;
  const [rows] = await pool.query(
    `${CUSTOMER_SELECT}
      WHERE (? = '' OR CONCAT(cu.first_name, ' ', cu.last_name) LIKE ? OR cu.customer_code LIKE ? OR cu.contact LIKE ?)
      ORDER BY cu.id LIMIT 1000`, [q, like, like, like]);
  res.json(rows.map(mapCustomer));
}));

// Customer profile + session history
router.get('/:id', wrap(async (req, res) => {
  const id = parseId(req.params.id, 'customer ID');
  const [rows] = await pool.query(`${CUSTOMER_SELECT} WHERE cu.id = ?`, [id]);
  if (!rows.length) throw new AppError(404, 'Customer not found.');
  const [sessions] = await pool.query(
    `${SESSION_SELECT} WHERE s.customer_id = ? ORDER BY s.start_time DESC, s.id DESC LIMIT 200`, [id]);
  res.json({ ...mapCustomer(rows[0]), sessions: sessions.map(mapSession) });
}));

// Create a customer record (cashier only). No username/password - customers never log in.
router.post('/', only('cashier'), wrap(async (req, res) => {
  const firstName = cleanStr(req.body.firstName, { max: 60, required: true, label: 'First name' });
  const lastName = cleanStr(req.body.lastName, { max: 60, required: true, label: 'Last name' });
  const contact = cleanStr(req.body.contact, { max: 30, label: 'Contact number' });
  const email = cleanStr(req.body.email, { max: 100, label: 'Email' });
  if (contact && !/^\+63\s?9\d{2}\s?\d{3}\s?\d{4}$/.test(contact)) throw new AppError(400, 'Contact number must use Philippine format, e.g. +63 917 123 4567.');
  if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new AppError(400, 'Email address is not valid.');

  const id = await withTransaction(async conn => {
    const [r] = await conn.query('INSERT INTO customers (first_name, last_name, contact, email) VALUES (?, ?, ?, ?)', [firstName, lastName, contact, email]);
    await conn.query('UPDATE customers SET customer_code = ? WHERE id = ?', [code('CUS', r.insertId, 3), r.insertId]);
    return r.insertId;
  });
  const [rows] = await pool.query(`${CUSTOMER_SELECT} WHERE cu.id = ?`, [id]);
  res.status(201).json(mapCustomer(rows[0]));
}));

module.exports = router;
