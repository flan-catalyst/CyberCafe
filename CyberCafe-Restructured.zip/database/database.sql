-- =====================================================================
--  CyberCafe - Session & Billing System  |  MySQL 8.0+ (5.7.8+ works too)
--  Run this whole file in MySQL Workbench (File > Open SQL Script > run).
--  It is SAFE TO RE-RUN: it never drops anything and never duplicates seed rows.
--  All timestamps are stored in UTC. The application displays Philippine time (Asia/Manila, UTC+08:00).
-- =====================================================================
SET time_zone = '+00:00';

CREATE DATABASE IF NOT EXISTS cybercafe
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE cybercafe;

CREATE TABLE IF NOT EXISTS users (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  username      VARCHAR(50)  NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('admin','cashier') NOT NULL,
  is_active     TINYINT(1)   NOT NULL DEFAULT 1,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_username (username)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS customers (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  customer_code VARCHAR(20)  NULL,
  first_name    VARCHAR(60)  NOT NULL,
  last_name     VARCHAR(60)  NOT NULL,
  contact       VARCHAR(30)  NULL,
  email         VARCHAR(100) NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_customers_code (customer_code),
  KEY idx_customers_name (last_name, first_name)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS computers (
  id            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  computer_name VARCHAR(30)  NOT NULL,
  status        ENUM('Available','In Use','Maintenance','Archived') NOT NULL DEFAULT 'Available',
  hourly_rate   DECIMAL(8,2) NOT NULL,
  created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  active_computer_name VARCHAR(30) GENERATED ALWAYS AS (IF(status = 'Archived', NULL, computer_name)) STORED,
  UNIQUE KEY uq_computers_active_name (active_computer_name),
  CONSTRAINT chk_computers_rate CHECK (hourly_rate > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS services (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name       VARCHAR(100) NOT NULL,
  price      DECIMAL(8,2) NOT NULL,
  unit       ENUM('page','item','service') NOT NULL DEFAULT 'page',
  is_active  TINYINT(1)   NOT NULL DEFAULT 1,
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_services_name (name),
  CONSTRAINT chk_services_price CHECK (price > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sessions (
  id                 INT UNSIGNED NOT NULL AUTO_INCREMENT,
  computer_id        INT UNSIGNED NOT NULL,
  customer_id        INT UNSIGNED NULL,
  guest_name         VARCHAR(100) NULL,
  started_by         INT UNSIGNED NOT NULL,
  ended_by           INT UNSIGNED NULL,
  start_time         DATETIME     NOT NULL,
  end_time           DATETIME     NULL,
  timer_mode         ENUM('open','fixed') NOT NULL DEFAULT 'open',
  duration_limit_seconds INT UNSIGNED NULL,
  expires_at         DATETIME     NULL,
  duration_seconds   INT UNSIGNED NULL,
  hourly_rate        DECIMAL(8,2) NOT NULL,
  rental_amount      DECIMAL(10,2) NULL,
  services_amount    DECIMAL(10,2) NULL,
  additional_fee_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  additional_fee_note VARCHAR(200) NULL,
  total_amount       DECIMAL(10,2) NULL,
  status             ENUM('Active','Completed') NOT NULL DEFAULT 'Active',
  end_reason         ENUM('Manual','Timeout') NULL,
  active_computer_id INT UNSIGNED GENERATED ALWAYS AS (IF(status = 'Active', computer_id, NULL)) STORED,
  PRIMARY KEY (id),
  UNIQUE KEY uq_one_active_session_per_pc (active_computer_id),
  KEY idx_sessions_computer (computer_id),
  KEY idx_sessions_customer (customer_id),
  KEY idx_sessions_start (start_time),
  KEY idx_sessions_status (status),
  KEY idx_sessions_expiry (status, expires_at),
  CONSTRAINT fk_sessions_computer FOREIGN KEY (computer_id) REFERENCES computers (id),
  CONSTRAINT fk_sessions_customer FOREIGN KEY (customer_id) REFERENCES customers (id),
  CONSTRAINT fk_sessions_started_by FOREIGN KEY (started_by) REFERENCES users (id),
  CONSTRAINT fk_sessions_ended_by FOREIGN KEY (ended_by) REFERENCES users (id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS session_services (
  id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id INT UNSIGNED NOT NULL,
  service_id INT UNSIGNED NOT NULL,
  quantity   INT UNSIGNED NOT NULL,
  unit_price DECIMAL(8,2) NOT NULL,
  PRIMARY KEY (id),
  KEY idx_ss_session (session_id),
  CONSTRAINT fk_ss_session FOREIGN KEY (session_id) REFERENCES sessions (id),
  CONSTRAINT fk_ss_service FOREIGN KEY (service_id) REFERENCES services (id),
  CONSTRAINT chk_ss_quantity CHECK (quantity > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
  id               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id       INT UNSIGNED NOT NULL,
  customer_id      INT UNSIGNED NULL,
  processed_by     INT UNSIGNED NOT NULL,
  amount           DECIMAL(10,2) NOT NULL,
  payment_method   ENUM('Cash','GCash','Card') NOT NULL DEFAULT 'Cash',
  payment_amount   DECIMAL(10,2) NOT NULL,
  change_amount    DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  transaction_date DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_transaction_session (session_id),
  KEY idx_tx_date (transaction_date),
  KEY idx_tx_customer (customer_id),
  CONSTRAINT fk_tx_session FOREIGN KEY (session_id) REFERENCES sessions (id),
  CONSTRAINT fk_tx_customer FOREIGN KEY (customer_id) REFERENCES customers (id),
  CONSTRAINT fk_tx_user FOREIGN KEY (processed_by) REFERENCES users (id),
  CONSTRAINT chk_tx_amounts CHECK (amount >= 0 AND payment_amount >= amount AND change_amount >= 0)
) ENGINE=InnoDB;

-- =====================================================================
--  SEED DATA  (no fake sessions / transactions are inserted)
-- =====================================================================

-- The 8 computers.  PC-05 starts in Maintenance (like the original mock-up).
INSERT INTO computers (computer_name, status, hourly_rate) VALUES
  ('PC-01', 'Available',   15.00),
  ('PC-02', 'Available',   15.00),
  ('PC-03', 'Available',   15.00),
  ('PC-04', 'Available',   18.00),
  ('PC-05', 'Maintenance', 15.00),
  ('PC-06', 'Available',   20.00),
  ('PC-07', 'Available',   15.00),
  ('PC-08', 'Available',   15.00)
ON DUPLICATE KEY UPDATE computer_name = computer_name;

-- Services from the original mock-up
INSERT INTO services (name, price, unit) VALUES
  ('Printing - Black & White', 3.00,  'page'),
  ('Printing - Color',         10.00, 'page'),
  ('Scanning',                 5.00,  'page'),
  ('Photocopy',                3.00,  'page'),
  ('Laminate',                10.00, 'item')
ON DUPLICATE KEY UPDATE name = name;

-- Keep Laminate active as an available service.
UPDATE services SET is_active = 1 WHERE LOWER(name) = 'laminate';
UPDATE services SET is_active = 0 WHERE LOWER(name) LIKE '%pico%pc%wash%';

-- SAMPLE CUSTOMERS (clearly sample data from the original mock-up - delete if you don't want them)
INSERT INTO customers (customer_code, first_name, last_name, contact, email) VALUES
  ('CUS-001', 'Juan', 'Dela Cruz', '+63 917 123 4567', 'juan@email.com'),
  ('CUS-002', 'Maria', 'Santos',   '+63 918 555 0192', 'maria@email.com'),
  ('CUS-003', 'Mark', 'Reyes',     '+63 920 234 9911', 'mark@email.com'),
  ('CUS-004', 'Ana', 'Cruz',       '+63 917 777 3311', 'ana@email.com'),
  ('CUS-005', 'Kevin', 'Tan',      '+63 922 111 2000', 'kevin@email.com')
ON DUPLICATE KEY UPDATE customer_code = customer_code;

-- ---------------------------------------------------------------------
-- OPTIONAL (recommended): a dedicated MySQL account for the backend instead of root.
-- Uncomment, change the password, then put the same values in backend/.env
-- ---------------------------------------------------------------------
-- CREATE USER IF NOT EXISTS 'cybercafe_app'@'localhost' IDENTIFIED BY 'ChangeThisPassword!';
-- GRANT SELECT, INSERT, UPDATE, DELETE ON cybercafe.* TO 'cybercafe_app'@'localhost';
-- FLUSH PRIVILEGES;


-- EXISTING DATABASE MIGRATION NOTE:
-- The backend automatically migrates an older installation on startup:
-- customers.name -> first_name + last_name, computer statuses gain Archived,
-- and sessions gain fixed/open timer fields and timeout tracking.


-- SECTION 3.3: SQL QUERY DEMONSTRATION
USE cybercafe;

-- 1. SELECT: Shows five customers sorted by name.
SELECT id, customer_code, first_name, last_name
FROM customers
ORDER BY last_name ASC, first_name ASC
LIMIT 5;

-- 2. INSERT: Adds a sample customer for testing.
INSERT INTO customers (customer_code, first_name, last_name, contact, email)
VALUES ('DEMO-SQL-001', 'SQL', 'Demo', '+63 900 000 0000', 'sql.demo@example.com')
ON DUPLICATE KEY UPDATE
    first_name = 'SQL',
    last_name = 'Demo',
    contact = '+63 900 000 0000',
    email = 'sql.demo@example.com';

-- 3. UPDATE: Changes the sample customer's contact and email.
UPDATE customers
SET contact = '+63 900 000 0001',
    email = 'sql.demo.updated@example.com'
WHERE customer_code = 'DEMO-SQL-001';

-- Checks the updated customer.
SELECT customer_code, first_name, last_name, contact, email
FROM customers
WHERE customer_code = 'DEMO-SQL-001';

-- 4. DELETE: Removes the sample customer used for testing.
DELETE FROM customers
WHERE customer_code = 'DEMO-SQL-001';

-- 5. Advanced query: Counts active services by unit and sorts the results.
SELECT unit,
       COUNT(*) AS active_service_count,
       MIN(price) AS lowest_price,
       MAX(price) AS highest_price
FROM services
WHERE is_active = 1
GROUP BY unit
ORDER BY active_service_count DESC, unit ASC;
