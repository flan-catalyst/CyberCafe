// MySQL connection pool. Every query in the project uses placeholders (?) - never string concatenation of user input.
const mysql = require('mysql2/promise');
const config = require('./config');

const pool = mysql.createPool({
  ...config.db,
  waitForConnections: true,
  connectionLimit: 10,
  charset: 'utf8mb4',
  timezone: 'Z',          // DATETIME values are stored/read as UTC
  decimalNumbers: true    // DECIMAL columns come back as numbers, not strings
});

// Make every connection use UTC so NOW()/UTC_TIMESTAMP() are consistent.
pool.pool.on('connection', conn => conn.query("SET time_zone = '+00:00'"));

async function withTransaction(fn) {
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    try { await conn.rollback(); } catch (_) { /* ignore */ }
    throw err;
  } finally {
    conn.release();
  }
}

module.exports = { pool, withTransaction };
