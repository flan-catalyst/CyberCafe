const express = require('express');
const { pool } = require('../db');
const { only } = require('../auth');
const { AppError, wrap, cleanStr, parseMoney, code } = require('../utils');

const router = express.Router();

const map = r => ({ id: r.id, code: code('SVC', r.id, 3), name: r.name, price: r.price, unit: r.unit, usage: r.usage_count });

router.get('/', wrap(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT sv.id, sv.name, sv.price, sv.unit,
            (SELECT COALESCE(SUM(ss.quantity), 0) FROM session_services ss WHERE ss.service_id = sv.id) AS usage_count
       FROM services sv WHERE sv.is_active = 1 ORDER BY sv.id`);
  res.json(rows.map(map));
}));

router.post('/', only('admin'), wrap(async (req, res) => {
  const name = cleanStr(req.body.name, { max: 100, required: true, label: 'Service name' });
  const price = parseMoney(req.body.price, 'Price');
  if (price <= 0) throw new AppError(400, 'Price must be greater than zero.');
  const unit = req.body.unit;
  if (!['page', 'item', 'service'].includes(unit)) throw new AppError(400, 'Unit must be page, item or service.');
  const [r] = await pool.query('INSERT INTO services (name, price, unit) VALUES (?, ?, ?)', [name, price, unit]);
  res.status(201).json({ id: r.insertId, code: code('SVC', r.insertId, 3), name, price, unit, usage: 0 });
}));

module.exports = router;
