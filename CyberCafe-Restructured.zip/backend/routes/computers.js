const express = require('express');
const { pool, withTransaction } = require('../db');
const { only } = require('../auth');
const { AppError, wrap, parseId, cleanStr, parseMoney, SESSION_SELECT, mapSession } = require('../utils');

const router = express.Router();

// All computers with their live status + current session (both roles can read)
router.get('/', wrap(async (req, res) => {
  const [pcs] = await pool.query(
    "SELECT id, computer_name, status, hourly_rate FROM computers ORDER BY status = 'Archived', LENGTH(computer_name), computer_name");
  const [active] = await pool.query(`${SESSION_SELECT} WHERE s.status = 'Active'`);
  const byPc = new Map(active.map(r => [r.computer_id, mapSession(r)]));
  res.json(pcs.map(p => ({
    id: p.id,
    name: p.computer_name,
    status: p.status,
    rate: p.hourly_rate,
    activeSession: byPc.get(p.id) || null
  })));
}));

// Add a computer (admin)
router.post('/', only('admin'), wrap(async (req, res) => {
  const name = cleanStr(req.body.name, { max: 30, required: true, label: 'Computer name' }).toUpperCase();
  if (!/^[A-Z0-9][A-Z0-9 _-]*$/.test(name)) throw new AppError(400, 'Computer name may only use letters, numbers, spaces, - and _.');
  const rate = parseMoney(req.body.hourlyRate, 'Hourly rate');
  if (rate <= 0) throw new AppError(400, 'Hourly rate must be greater than zero.');
  const [r] = await pool.query('INSERT INTO computers (computer_name, status, hourly_rate) VALUES (?, ?, ?)', [name, 'Available', rate]);
  res.status(201).json({ id: r.insertId, name, status: 'Available', rate, activeSession: null });
}));

// Change hourly rate and/or set Available <-> Maintenance (admin).
// "In Use" can only be set by starting a session. Rate changes only affect FUTURE sessions.
router.patch('/:id', only('admin'), wrap(async (req, res) => {
  const id = parseId(req.params.id, 'computer ID');
  const { hourlyRate, status } = req.body;
  if (hourlyRate === undefined && status === undefined) throw new AppError(400, 'Nothing to update.');
  let rate = null;
  if (hourlyRate !== undefined) {
    rate = parseMoney(hourlyRate, 'Hourly rate');
    if (rate <= 0) throw new AppError(400, 'Hourly rate must be greater than zero.');
  }
  if (status !== undefined && !['Available', 'Maintenance', 'Archived'].includes(status)) {
    throw new AppError(400, 'Status must be Available, Maintenance, or Archived.');
  }
  await withTransaction(async conn => {
    const [rows] = await conn.query('SELECT id, status FROM computers WHERE id = ? FOR UPDATE', [id]);
    if (!rows.length) throw new AppError(404, 'Computer not found.');
    if (status !== undefined && rows[0].status === 'In Use') {
      throw new AppError(409, 'This computer has an active session. The cashier must end it first.');
    }
    if (rate !== null) await conn.query('UPDATE computers SET hourly_rate = ? WHERE id = ?', [rate, id]);
    if (status !== undefined) await conn.query('UPDATE computers SET status = ? WHERE id = ?', [status, id]);
  });
  res.json({ ok: true });
}));

// Archive a computer instead of deleting it. Archived names can be reused by a replacement unit.
router.delete('/:id', only('admin'), wrap(async (req, res) => {
  const id = parseId(req.params.id, 'computer ID');
  await withTransaction(async conn => {
    const [rows] = await conn.query('SELECT id, status FROM computers WHERE id = ? FOR UPDATE', [id]);
    if (!rows.length) throw new AppError(404, 'Computer not found.');
    if (rows[0].status === 'In Use') throw new AppError(409, 'Cannot archive a computer with an active session.');
    await conn.query("UPDATE computers SET status = 'Archived' WHERE id = ?", [id]);
  });
  res.json({ ok: true });
}));

module.exports = router;
