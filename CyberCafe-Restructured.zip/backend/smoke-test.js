// Automated check of the 12 required test scenarios against a RUNNING server.
//   1) start the backend (npm start)   2) in a second window:  npm test
// WARNING: this creates real test rows (a "TEST Customer", a few sessions and payments).
// Run it on a fresh database BEFORE opening the cafe, or re-create the database afterwards
// (see README, "Resetting test data").
//
// Optional environment variables: BASE_URL, TEST_ADMIN_USER/PASS, TEST_CASHIER_USER/PASS
const BASE = process.env.BASE_URL || 'http://localhost:3000';
const ADMIN = { username: process.env.TEST_ADMIN_USER || 'admin', password: process.env.TEST_ADMIN_PASS || 'admin123' };
const CASHIER = { username: process.env.TEST_CASHIER_USER || 'cashier', password: process.env.TEST_CASHIER_PASS || 'cashier123' };

class Client {
  constructor() { this.cookie = ''; }
  async call(method, path, body) {
    const headers = { 'Content-Type': 'application/json' };
    if (this.cookie) headers.Cookie = this.cookie;
    const res = await fetch(`${BASE}/api${path}`, { method, headers, body: body ? JSON.stringify(body) : undefined });
    const raw = typeof res.headers.getSetCookie === 'function'
      ? res.headers.getSetCookie()
      : (res.headers.get('set-cookie') ? [res.headers.get('set-cookie')] : []);
    if (raw.length) this.cookie = raw.map(c => c.split(';')[0]).join('; ');
    let data = null;
    try { data = await res.json(); } catch (_) { /* no body */ }
    return { status: res.status, data };
  }
}

let passed = 0;
let failed = 0;
function check(name, ok, detail = '') {
  if (ok) { passed++; console.log(`  PASS  ${name}`); }
  else { failed++; console.log(`  FAIL  ${name} ${detail}`); }
}
const sleep = ms => new Promise(r => setTimeout(r, ms));
const expectedRental = (secs, rate) => secs < 1800 ? Math.floor(Math.round(rate * 100) / 200) : Math.round((secs * Math.round(rate * 100)) / 3600) / 100;

(async () => {
  const admin = new Client();
  const cashier = new Client();
  const anon = new Client();

  console.log(`\nCyberCafe smoke test against ${BASE}\n`);

  const a = await admin.call('POST', '/auth/login', ADMIN);
  const c = await cashier.call('POST', '/auth/login', CASHIER);
  check('Admin can sign in', a.status === 200 && a.data.user.role === 'admin', JSON.stringify(a.data));
  check('Cashier can sign in', c.status === 200 && c.data.user.role === 'cashier', JSON.stringify(c.data));
  if (a.status !== 200 || c.status !== 200) {
    console.log('\nCannot continue without both logins. Check the credentials / that the server is running.');
    process.exit(1);
  }

  // ---------------------------------------------------------------- TEST 1
  console.log('\nTEST 1  Create a customer record');
  const stamp = Date.now().toString().slice(-6);
  const cr = await cashier.call('POST', '/customers', { firstName: 'TEST', lastName: `Customer ${stamp}`, contact: '+63 917 000 0000', email: 'test@example.com' });
  check('Customer created (201) with a CUS- code', cr.status === 201 && /^CUS-\d{3,}$/.test(cr.data.code), JSON.stringify(cr.data));
  const customer = cr.data;

  const pcList = (await cashier.call('GET', '/computers')).data;
  const free = pcList.filter(p => p.status === 'Available');
  if (free.length < 2) { console.log('Need at least 2 Available computers to run the test.'); process.exit(1); }
  const pcA = free[0];
  const pcB = free[1];

  // ---------------------------------------------------------------- TEST 2
  console.log(`\nTEST 2  Start a Guest session on ${pcA.name}`);
  const s1 = await cashier.call('POST', '/sessions/start', { computerId: pcA.id, customerType: 'guest', guestName: 'TEST Guest' });
  check('Guest session started (201)', s1.status === 201 && s1.data.status === 'Active' && s1.data.customerId === null, JSON.stringify(s1.data));
  const afterStart = (await cashier.call('GET', '/computers')).data.find(p => p.id === pcA.id);
  check('Computer changed Available -> In Use', afterStart.status === 'In Use');

  // ---------------------------------------------------------------- TEST 3
  console.log('\nTEST 3  "Refresh the page" (fresh request from a new client)');
  const fresh = new Client();
  await fresh.call('POST', '/auth/login', CASHIER);
  const refreshed = (await fresh.call('GET', '/computers')).data.find(p => p.id === pcA.id);
  check('Computer is still In Use with its session', refreshed.status === 'In Use' && refreshed.activeSession && refreshed.activeSession.id === s1.data.id);

  // ---------------------------------------------------------------- TEST 4
  console.log('\nTEST 4  Start another session on the same computer');
  const dup = await cashier.call('POST', '/sessions/start', { computerId: pcA.id, customerType: 'guest' });
  check('Second session rejected (409)', dup.status === 409, `${dup.status} ${JSON.stringify(dup.data)}`);
  const bad = await cashier.call('POST', '/sessions/start', { computerId: pcB.id, customerType: 'existing', customerId: 99999999 });
  check('Invalid customer ID rejected (400)', bad.status === 400, `${bad.status} ${JSON.stringify(bad.data)}`);
  const maint = pcList.find(p => p.status === 'Maintenance');
  if (maint) {
    const m = await cashier.call('POST', '/sessions/start', { computerId: maint.id, customerType: 'guest' });
    check('Session on a Maintenance computer rejected (409)', m.status === 409);
  }

  // ---------------------------------------------------------------- TEST 5
  console.log('\nTEST 5  End the guest session');
  await sleep(3000);
  const end1 = await cashier.call('POST', `/sessions/${s1.data.id}/end`, { services: [] });
  check('Session ended (200) and marked Completed', end1.status === 200 && end1.data.status === 'Completed', JSON.stringify(end1.data));
  check('Duration is at least 3 seconds', end1.data.durationSeconds >= 3, String(end1.data.durationSeconds));
  check('Bill = duration x hourly rate (calculated by the server)',
    Math.abs(end1.data.totalAmount - expectedRental(end1.data.durationSeconds, end1.data.rate)) < 0.0001,
    `${end1.data.totalAmount} vs ${expectedRental(end1.data.durationSeconds, end1.data.rate)}`);
  const end1b = await cashier.call('POST', `/sessions/${s1.data.id}/end`, {});
  check('Ending the same session twice is rejected (409)', end1b.status === 409);

  // ---------------------------------------------------------------- TEST 6
  console.log('\nTEST 6  Record payment');
  const total1 = end1.data.totalAmount;
  const under = await cashier.call('POST', '/transactions', { sessionId: s1.data.id, paymentMethod: 'Cash', paymentAmount: Math.max(0, total1 - 0.01) });
  check('Underpayment rejected (400)', total1 < 0.01 || under.status === 400, `${under.status}`);
  const pay1 = await cashier.call('POST', '/transactions', { sessionId: s1.data.id, paymentMethod: 'Cash', paymentAmount: total1 + 10 });
  check('Payment stored (201) with correct change',
    pay1.status === 201 && pay1.data.transaction && Math.abs(pay1.data.transaction.change - 10) < 0.0001, JSON.stringify(pay1.data));
  const pay1b = await cashier.call('POST', '/transactions', { sessionId: s1.data.id, paymentMethod: 'Cash', paymentAmount: total1 + 10 });
  check('Paying twice is rejected (409)', pay1b.status === 409);
  const txs = (await cashier.call('GET', '/transactions?limit=500')).data;
  check('Transaction appears in transaction history', txs.some(t => t.sessionId === s1.data.id));

  // ---------------------------------------------------------------- TEST 7
  console.log('\nTEST 7  Computer status after the session');
  const afterEnd = (await cashier.call('GET', '/computers')).data.find(p => p.id === pcA.id);
  check('Computer is Available again', afterEnd.status === 'Available' && afterEnd.activeSession === null);

  // ---------------------------------------------------------------- TEST 8
  console.log('\nTEST 8  Start a session for an Existing Customer');
  const s2 = await cashier.call('POST', '/sessions/start', { computerId: pcA.id, customerType: 'existing', customerId: customer.id });
  check('Session linked to the customer', s2.status === 201 && s2.data.customerId === customer.id, JSON.stringify(s2.data));
  await sleep(2000);
  const services = (await cashier.call('GET', '/services')).data;
  const lines = services.length ? [{ serviceId: services[0].id, quantity: 2 }] : [];
  const end2 = await cashier.call('POST', `/sessions/${s2.data.id}/end`, { services: lines });
  check('Session with a service line ended', end2.status === 200, JSON.stringify(end2.data));
  if (lines.length) {
    check('Service total calculated by the server', Math.abs(end2.data.servicesAmount - services[0].price * 2) < 0.0001, String(end2.data.servicesAmount));
  }
  const exact = end2.data.totalAmount;
  const gcashBad = await cashier.call('POST', '/transactions', { sessionId: s2.data.id, paymentMethod: 'GCash', paymentAmount: exact + 5 });
  check('GCash over-payment rejected (400)', gcashBad.status === 400);
  const pay2 = await cashier.call('POST', '/transactions', { sessionId: s2.data.id, paymentMethod: 'GCash', paymentAmount: exact });
  check('GCash exact payment stored', pay2.status === 201, JSON.stringify(pay2.data));

  // ---------------------------------------------------------------- TEST 9
  console.log('\nTEST 9  Customer history');
  const hist = await cashier.call('GET', `/customers/${customer.id}`);
  check('Completed session is visible in the customer history',
    hist.status === 200 && hist.data.sessions.some(s => s.id === s2.data.id && s.status === 'Completed'));
  check('Customer totals updated', hist.data.completedSessions === 1 && Math.abs(hist.data.totalSpent - exact) < 0.0001);

  // ---------------------------------------------------------------- TEST 10
  console.log('\nTEST 10  Admin statistics come from the database');
  const stats = await admin.call('GET', '/admin/stats');
  check('Stats endpoint works for admin', stats.status === 200, JSON.stringify(stats.data));
  const all = (await admin.call('GET', '/transactions?limit=500')).data;
  if (all.length < 500) {
    const sum = all.reduce((x, t) => x + t.amount, 0);
    check('Total revenue equals the sum of stored transactions', Math.abs(stats.data.totalRevenue - sum) < 0.005, `${stats.data.totalRevenue} vs ${sum}`);
  }
  check('Computer counts add up', stats.data.computers.total === stats.data.computers.inUse + stats.data.computers.available + stats.data.computers.maintenance);
  const rev = await admin.call('GET', '/admin/revenue?days=7');
  check('Revenue-over-time returns 7 days', rev.status === 200 && rev.data.length === 7);
  const usage = await admin.call('GET', '/admin/computer-usage');
  check('Computer-usage report works', usage.status === 200 && Array.isArray(usage.data));

  // ---------------------------------------------------------------- TEST 11
  console.log('\nTEST 11  Permissions are enforced by the backend');
  check('Cashier cannot read admin statistics (403)', (await cashier.call('GET', '/admin/stats')).status === 403);
  check('Cashier cannot list users (403)', (await cashier.call('GET', '/users')).status === 403);
  check('Cashier cannot add computers (403)', (await cashier.call('POST', '/computers', { name: 'PC-99', hourlyRate: 10 })).status === 403);
  check('Cashier cannot add services (403)', (await cashier.call('POST', '/services', { name: 'X', price: 1, unit: 'page' })).status === 403);
  const s3 = await cashier.call('POST', '/sessions/start', { computerId: pcB.id, customerType: 'guest' });
  check('Cashier starts a session on the second PC', s3.status === 201);
  check('Admin cannot start sessions (403)', (await admin.call('POST', '/sessions/start', { computerId: pcA.id, customerType: 'guest' })).status === 403);
  check('Admin cannot end sessions (403)', (await admin.call('POST', `/sessions/${s3.data.id}/end`, {})).status === 403);
  check('Admin cannot process payments (403)', (await admin.call('POST', '/transactions', { sessionId: s1.data.id, paymentMethod: 'Cash', paymentAmount: 100 })).status === 403);
  check('Admin cannot create customers (403)', (await admin.call('POST', '/customers', { name: 'Nope' })).status === 403);
  check('Not signed in -> 401', (await anon.call('GET', '/computers')).status === 401);
  await sleep(1000);
  await cashier.call('POST', `/sessions/${s3.data.id}/end`, {});
  await cashier.call('POST', '/transactions', { sessionId: s3.data.id, paymentMethod: 'Cash', paymentAmount: 100 });

  // ---------------------------------------------------------------- TEST 12
  console.log('\nTEST 12  Customers have no login');
  const cl = await anon.call('POST', '/auth/login', { username: customer.code, password: 'anything' });
  check('A customer ID / name cannot be used to sign in (401)', cl.status === 401);
  const clist = (await cashier.call('GET', '/customers')).data;
  check('Customer records contain no username/password fields',
    clist.every(x => !('password' in x) && !('username' in x) && !('password_hash' in x)));
  check('There is no customer-login endpoint (404)', (await anon.call('POST', '/customer-login', {})).status === 404);

  console.log(`\nResult: ${passed} passed, ${failed} failed\n`);
  process.exit(failed ? 1 : 0);
})().catch(err => {
  console.error('\nTest run crashed - is the server running?  ', err.message);
  process.exit(1);
});
