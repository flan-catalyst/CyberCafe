// Central configuration (reads backend/.env). Credentials stay on the server only.
const path = require('path');
const crypto = require('crypto');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const tzOffset = process.env.CAFE_TZ_OFFSET || '+08:00';
const timeZone = process.env.CAFE_TIME_ZONE || 'Asia/Manila';
if (!/^[+-]\d{2}:\d{2}$/.test(tzOffset)) {
  throw new Error('CAFE_TZ_OFFSET must look like +08:00');
}

let sessionSecret = process.env.SESSION_SECRET;
if (!sessionSecret || sessionSecret.length < 16 || sessionSecret.startsWith('change-this')) {
  sessionSecret = crypto.randomBytes(32).toString('hex');
  console.warn('[config] SESSION_SECRET is not set - using a random one. Staff will be signed out whenever the server restarts.');
}

module.exports = {
  port: Number(process.env.PORT) || 3000,
  host: process.env.HOST || '0.0.0.0',
  db: {
    host: process.env.DB_HOST || 'localhost',
    port: Number(process.env.DB_PORT) || 3306,
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
    database: process.env.DB_NAME || 'cybercafe'
  },
  sessionSecret,
  tzOffset,
  timeZone,
  defaultAdminPassword: process.env.DEFAULT_ADMIN_PASSWORD || 'admin123',
  defaultCashierPassword: process.env.DEFAULT_CASHIER_PASSWORD || 'cashier123'
};
