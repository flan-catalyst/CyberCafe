/* =====================================================================
   CyberCafe — Session & Billing System (frontend)
   Every piece of data below comes from the backend API / MySQL database.
   Nothing is stored in JavaScript, so a page refresh never loses a session.
   The totals shown while a session is running are only an on-screen estimate;
   the server measures the time and calculates the real bill when the session ends.
   ===================================================================== */
const API_BASE = window.CYBERCAFE_API_BASE || "";   // same server by default

const state = {
  user: null, page: "dashboard", range: 14,
  customers: [], computers: [], services: [], sessions: [], activeSessions: [], users: [],
  admin: null, live: {}, charts: [],
  sessionFilter: { q: "", status: "", sort: "date_desc", date: "" },
  billingFilter: { q: "", sort: "date_desc" }
};
let renderToken = 0;
let endCtx = null;          // data for the "End Session" modal
let offlineToastAt = 0;

/* ------------------------------------------------------------------ helpers */
const $ = s => document.querySelector(s);
const money = n => "₱" + Number(n || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const esc = s => String(s ?? "").replace(/[&<>"']/g, m => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;" }[m]));
const PH_TZ = "Asia/Manila";
const fmtTime = d => d ? new Date(d).toLocaleTimeString("en-PH", { hour: "2-digit", minute: "2-digit", timeZone: PH_TZ }) : "—";
const fmtDate = d => d ? new Date(d).toLocaleDateString("en-PH", { year: "numeric", month: "short", day: "numeric", timeZone: PH_TZ }) : "—";
const fmtDT = d => d ? new Date(d).toLocaleString("en-PH", { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", timeZone: PH_TZ }) : "—";
const pad2 = n => String(n).padStart(2, "0");
const durText = sec => { const m = Math.floor((sec || 0) / 60), h = Math.floor(m / 60); return `${h}h ${pad2(m % 60)}m`; };
const clockText = sec => { sec = Math.max(0, Math.floor(sec || 0)); return `${pad2(Math.floor(sec / 3600))}:${pad2(Math.floor(sec / 60) % 60)}:${pad2(sec % 60)}`; };
const isAdmin = () => !!state.user && state.user.role === "admin";
const isCashier = () => !!state.user && state.user.role === "cashier";

function statusBadge(status) {
  const cls = { "Available": "status-available", "In Use": "status-use", "Maintenance": "status-maint", "Archived": "status-maint", "Active": "status-use", "Completed": "status-available", "Pending": "status-reserved", "Paid": "status-available" }[status] || "badge-soft";
  return `<span class="badge badge-soft ${cls}">${esc(status)}</span>`;
}

/* Live (on-screen) timers: the server tells us how many seconds a session has run when
   the data was loaded; we add the time that passed in the browser since then. */
function indexSessions(list) {
  const now = performance.now();
  (list || []).forEach(s => { if (s && s.status === "Active") { s._at = now; state.live[s.id] = s; } });
}
const liveSeconds = s => s.durationSeconds + (performance.now() - (s._at || performance.now())) / 1000;
const liveAmount = s => Math.round(liveSeconds(s) * Math.round(s.rate * 100) / 3600) / 100;
const liveRemaining = s => s.timerMode === "fixed" ? Math.max(0, (s.remainingSeconds || 0) - (performance.now() - (s._at || performance.now())) / 1000) : null;

/* ---------------------------------------------------------------------- API */
class ApiError extends Error { constructor(status, message) { super(message); this.status = status; } }

async function api(path, { method = "GET", body } = {}) {
  let res;
  try {
    res = await fetch(API_BASE + "/api" + path, {
      method, credentials: "same-origin",
      headers: body !== undefined ? { "Content-Type": "application/json" } : {},
      body: body !== undefined ? JSON.stringify(body) : undefined
    });
  } catch (e) {
    throw new ApiError(0, "Cannot reach the CyberCafe server. Check that the backend is running and the network is connected.");
  }
  let data = null;
  try { data = await res.json(); } catch (e) { /* no JSON body */ }
  if (!res.ok) {
    if (res.status === 401 && state.user && !path.startsWith("/auth/")) {
      state.user = null;
      toast("Your session expired. Please sign in again.", "danger");
      setTimeout(() => location.reload(), 1200);
    }
    throw new ApiError(res.status, (data && data.error) || `Request failed (${res.status}).`);
  }
  return data;
}

/* ------------------------------------------------------------------- render */
async function loadData(page) {
  state.live = {};
  if (page === "dashboard") {
    if (isAdmin()) {
      const d = state.range;
      const [stats, revenue, sessionsOT, usage, computers, active] = await Promise.all([
        api("/admin/stats"), api(`/admin/revenue?days=${d}`), api(`/admin/sessions-over-time?days=${d}`),
        api("/admin/computer-usage"), api("/computers"), api("/sessions?status=Active")
      ]);
      state.admin = { stats, revenue, sessionsOT, usage };
      state.computers = computers; state.activeSessions = active;
    } else {
      const [computers, active, customers] = await Promise.all([api("/computers"), api("/sessions?status=Active"), api("/customers")]);
      state.computers = computers; state.activeSessions = active; state.customers = customers;
    }
    indexSessions(state.activeSessions);
  } else if (page === "customers") {
    state.customers = await api("/customers");
  } else if (page === "computers") {
    state.computers = await api("/computers");
  } else if (page === "sessions") {
    const f = state.sessionFilter;
    state.sessions = await api(`/sessions?limit=300&status=${encodeURIComponent(f.status)}&q=${encodeURIComponent(f.q)}`);
    sortSessions();
  } else if (page === "billing") {
    const f = state.billingFilter;
    state.sessions = await api(`/sessions?status=Completed&limit=300&q=${encodeURIComponent(f.q)}`);
    sortBilling();
  } else if (page === "services") {
    state.services = await api("/services");
  } else if (page === "users") {
    state.users = await api("/users");
  }
  state.computers.forEach(pc => indexSessions(pc.activeSession ? [pc.activeSession] : []));
  indexSessions(state.sessions);
}

async function render(page = state.page, silent = false) {
  if (!state.user) return;
  const titles = { dashboard: "Dashboard", customers: "Customers", computers: "Computer Units", sessions: "Session Logs", billing: "Billing & Payments", services: "Services", users: "Users & Roles" };
  const views = { dashboard: dashboardView, customers: customersView, computers: computersView, sessions: sessionsView, billing: billingView, services: servicesView, users: usersView };
  if (!views[page]) page = "dashboard";
  const token = ++renderToken;
  state.page = page;
  $("#pageTitle").textContent = titles[page];
  document.querySelectorAll("#nav .nav-link[data-page]").forEach(b => b.classList.toggle("active", b.dataset.page === page));
  if (!silent) $("#content").innerHTML = `<div class="empty">Loading…</div>`;
  try {
    await loadData(page);
  } catch (e) {
    if (token !== renderToken) return;
    if (silent) {
      if (e.status === 0 && Date.now() - offlineToastAt > 60000) { offlineToastAt = Date.now(); toast(e.message, "danger"); }
      return;
    }
    $("#content").innerHTML = `<div class="empty"><i class="bi bi-exclamation-triangle fs-3"></i><div class="mt-2">${esc(e.message)}</div><button class="btn btn-outline-light mt-3" onclick="render('${page}')">Try again</button></div>`;
    return;
  }
  if (token !== renderToken) return;
  destroyCharts();
  $("#content").innerHTML = views[page]();
  attachPageEvents(page, silent);
}

/* ---------------------------------------------------------------- dashboard */
function dashboardView() { return isAdmin() ? adminDashboardView() : cashierDashboardView(); }

function stat(label, value, icon) {
  return `<div class="col-sm-6 col-xl-3"><div class="stat"><i class="bi ${icon}"></i><div class="label mt-2">${label}</div><div class="value">${value}</div></div></div>`;
}

function cashierDashboardView() {
  const pcs = state.computers, active = state.activeSessions;
  const available = pcs.filter(c => c.status === "Available").length;
  const maint = pcs.filter(c => c.status === "Maintenance").length;
  return `<div class="d-flex justify-content-between align-items-center mb-4">
    <div><h4 class="mb-1">Good day, ${esc(state.user.username)}</h4><p class="text-secondary mb-0">Cashier workspace: start and end sessions, customer records, and billing.</p></div>
    <button class="btn btn-primary" onclick="openStartSession()"><i class="bi bi-play-circle me-2"></i>Start Session</button>
  </div>
  <div class="row g-3 mb-4">
    ${stat("Available", available, "bi-pc-display")}
    ${stat("Active Sessions", active.length, "bi-stopwatch")}
    ${stat("Customers", state.customers.length, "bi-people")}
    ${stat("Under Maintenance", maint, "bi-tools")}
  </div>
  <div class="row g-4">
    <div class="col-xl-8"><div class="panel"><div class="panel-head"><strong>Computer Units</strong><button class="btn btn-sm btn-outline-light" onclick="render('computers')">Open</button></div><div class="panel-body"><div class="row g-3">${pcs.map(pc => pcCard(pc, false, false)).join("") || `<div class="empty">No computers found.</div>`}</div></div></div></div>
    <div class="col-xl-4"><div class="panel h-100"><div class="panel-head"><strong>Active Sessions</strong><span class="badge badge-soft">${active.length}</span></div><div class="panel-body">${active.length ? active.map(activeMini).join("") : `<div class="empty">No active sessions.</div>`}</div></div></div>
  </div>`;
}

function adminDashboardView() {
  const a = state.admin, st = a.stats, pc = st.computers;
  const hasRev = a.revenue.some(x => x.transactions > 0);
  const hasSes = a.sessionsOT.some(x => x.sessions > 0);
  const hasUse = a.usage.some(x => x.sessions > 0);
  const range = `<select id="rangeSel" class="form-select form-select-sm" style="width:auto">${[7, 14, 30, 90].map(d => `<option value="${d}" ${d === state.range ? "selected" : ""}>Last ${d} days</option>`).join("")}</select>`;
  const box = (id, has) => has ? `<div class="chart-box"><canvas id="${id}"></canvas></div>` : `<div class="empty">No data available</div>`;
  return `<div class="d-flex justify-content-between align-items-center mb-4">
    <div><h4 class="mb-1">Good day, ${esc(state.user.username)}</h4><p class="text-secondary mb-0">Business statistics and monitoring. Sessions are started and ended by cashiers.</p></div>
  </div>
  <div class="row g-3 mb-3">
    ${stat("Today's Revenue", money(st.todayRevenue), "bi-cash-stack")}
    ${stat("Total Revenue", money(st.totalRevenue), "bi-wallet2")}
    ${stat("Sessions Today", st.sessionsToday, "bi-stopwatch")}
    ${stat("Currently In Use", `${pc.inUse} / ${pc.total}`, "bi-pc-display")}
  </div>
  <div class="row g-3 mb-4">
    ${stat("Available", `${pc.available} / ${pc.total}`, "bi-check-circle")}
    ${stat("Under Maintenance", `${pc.maintenance} / ${pc.total}`, "bi-tools")}
    ${stat("Total Usage Time", st.completedSessions ? durText(st.totalUsageSeconds) : "No data available", "bi-clock-history")}
    ${stat("Average Session", st.completedSessions ? durText(st.avgSessionSeconds) : "No data available", "bi-hourglass-split")}
  </div>
  <div class="row g-4 mb-4">
    <div class="col-xl-6"><div class="panel h-100"><div class="panel-head"><strong>Revenue Over Time</strong>${range}</div><div class="panel-body">${box("chartRevenue", hasRev)}</div></div></div>
    <div class="col-xl-6"><div class="panel h-100"><div class="panel-head"><strong>Sessions Over Time</strong><span class="small text-secondary">Last ${state.range} days</span></div><div class="panel-body">${box("chartSessions", hasSes)}</div></div></div>
    <div class="col-xl-6"><div class="panel h-100"><div class="panel-head"><strong>Most-Used Computers</strong><span class="small text-secondary">Completed sessions</span></div><div class="panel-body">${box("chartMostUsed", hasUse)}</div></div></div>
    <div class="col-xl-6"><div class="panel h-100"><div class="panel-head"><strong>Computer Usage</strong><span class="small text-secondary">Hours used</span></div><div class="panel-body">${box("chartUsage", hasUse)}</div></div></div>
  </div>
  <div class="row g-4">
    <div class="col-xl-8"><div class="panel"><div class="panel-head"><strong>Computer Units</strong><button class="btn btn-sm btn-outline-light" onclick="render('computers')">Manage</button></div><div class="panel-body"><div class="row g-3">${state.computers.map(pc => pcCard(pc, true)).join("")}</div></div></div></div>
    <div class="col-xl-4"><div class="panel h-100"><div class="panel-head"><strong>Active Sessions</strong><span class="badge badge-soft">${state.activeSessions.length}</span></div><div class="panel-body">${state.activeSessions.length ? state.activeSessions.map(activeMini).join("") : `<div class="empty">No active sessions.</div>`}</div></div></div>
  </div>`;
}

function destroyCharts() { state.charts.forEach(c => c.destroy()); state.charts = []; }

function drawCharts(animate) {
  if (!isAdmin() || state.page !== "dashboard" || !state.admin) return;
  if (typeof Chart === "undefined") return;
  Chart.defaults.color = "#9eabc3";
  Chart.defaults.borderColor = "#263453";
  const a = state.admin;
  const short = d => new Date(d + "T00:00:00").toLocaleDateString([], { month: "short", day: "numeric" });
  const base = (extra = {}) => ({ responsive: true, maintainAspectRatio: false, animation: animate ? {} : false, plugins: { legend: { display: false } }, ...extra });
  const mk = (id, cfg) => { const el = document.getElementById(id); if (el) state.charts.push(new Chart(el, cfg)); };
  const used = a.usage.filter(x => x.sessions > 0);

  mk("chartRevenue", { type: "line", data: { labels: a.revenue.map(x => short(x.date)), datasets: [{ label: "Revenue (₱)", data: a.revenue.map(x => x.revenue), borderColor: "#4f8cff", backgroundColor: "rgba(79,140,255,.15)", fill: true, tension: .3 }] }, options: base({ scales: { y: { beginAtZero: true } } }) });
  mk("chartSessions", { type: "bar", data: { labels: a.sessionsOT.map(x => short(x.date)), datasets: [{ label: "Sessions", data: a.sessionsOT.map(x => x.sessions), backgroundColor: "#25c78a" }] }, options: base({ scales: { y: { beginAtZero: true, ticks: { precision: 0 } } } }) });
  mk("chartMostUsed", { type: "bar", data: { labels: used.map(x => x.name), datasets: [{ label: "Sessions", data: used.map(x => x.sessions), backgroundColor: "#f4b942" }] }, options: base({ indexAxis: "y", scales: { x: { beginAtZero: true, ticks: { precision: 0 } } } }) });
  mk("chartUsage", { type: "bar", data: { labels: used.map(x => x.name), datasets: [{ label: "Hours", data: used.map(x => Math.round(x.usageSeconds / 36) / 100), backgroundColor: "#72baff" }] }, options: base({ scales: { y: { beginAtZero: true } } }) });
}

function pcCard(pc, readonly = false, showServiceTools = true) {
  const a = pc.activeSession;
  let actions = "";
  if (!readonly) {
    if (isCashier()) {
      if (a) actions = showServiceTools ? `<div class="d-flex gap-2 mt-3"><button class="btn btn-sm btn-outline-light flex-fill" onclick="openAddActiveService(${a.id})"><i class="bi bi-plus-circle me-1"></i>Add Service</button><button class="btn btn-sm btn-danger flex-fill" onclick="openEndSession(${a.id})">End Session</button></div>` : `<button class="btn btn-sm btn-danger w-100 mt-3" onclick="openEndSession(${a.id})">End Session</button>`;
      else if (pc.status === "Available") actions = `<button class="btn btn-sm btn-primary w-100 mt-3" onclick="openStartSession(${pc.id})">Start Session</button>`;
      else actions = `<div class="small text-secondary mt-3">Not available — under maintenance</div>`;
    } else if (isAdmin() && !a && pc.status !== "Archived") {
      actions = `<div class="d-flex gap-2 mt-3"><button class="btn btn-sm btn-outline-light flex-fill" onclick="openEditComputer(${pc.id})"><i class="bi bi-pencil me-1"></i>Edit Rate</button><button class="btn btn-sm btn-outline-light" title="Change status" onclick="changeComputerStatus(${pc.id})"><i class="bi bi-sliders"></i></button><button class="btn btn-sm btn-outline-danger" title="Archive computer" onclick="removeComputer(${pc.id})"><i class="bi bi-archive"></i></button></div>`;
    }
  }
  return `<div class="col-md-6 col-xl-3"><div class="pc-card">
    <i class="bi bi-pc-display pc-icon"></i><div class="pc-card-heading"><div><h5>${esc(pc.name)}</h5><div class="text-secondary small">${money(pc.rate)}/hour</div></div>${statusBadge(pc.status)}</div>
    ${a ? `<div class="mt-3 small text-secondary">${esc(a.customerName)}<br>Started ${fmtTime(a.start)}${a.timerMode === "fixed" ? `<br>Time left: <span class="live-rem" data-session="${a.id}">${clockText(liveRemaining(a))}</span>` : ` · <span class="live-cost" data-session="${a.id}">${money(liveAmount(a))}</span>`}${showServiceTools && Number(a.servicesAmount || 0) > 0 ? `<br>Services added: ${money(a.servicesAmount)}` : ""}</div>` : ""}
    ${actions}
  </div></div>`;
}

function activeMini(s) {
  const fixedTime = s.timerMode === "fixed";
  return `<div class="quick mb-2"><div class="d-flex justify-content-between"><strong>${esc(s.customerName)}</strong>${statusBadge("Active")}</div><div class="small text-secondary">${esc(s.computerName)} · Started ${fmtTime(s.start)}${fixedTime ? "" : ` · <span class="live-dur" data-session="${s.id}">${clockText(liveSeconds(s))}</span>`}</div>${fixedTime ? `<div class="fw-bold mt-1">Time left: <span class="live-rem" data-session="${s.id}">${clockText(liveRemaining(s))}</span></div>` : `<div class="fw-bold mt-1 live-cost" data-session="${s.id}">${money(liveAmount(s))}</div>`}</div>`;
}

/* ---------------------------------------------------------------- customers */
function customersView() {
  return `<div class="d-flex flex-wrap gap-2 justify-content-between mb-4"><div><p class="text-secondary mb-1">Customer records and history</p></div>${isCashier() ? `<button class="btn btn-primary" onclick="openCustomer()"><i class="bi bi-person-plus me-2"></i>Add Customer</button>` : ""}</div>
  <div class="panel"><div class="panel-head"><div class="input-group" style="max-width:430px"><span class="input-group-text bg-transparent text-secondary border-secondary"><i class="bi bi-search"></i></span><input id="customerSearch" class="form-control" placeholder="Search name, ID, or contact"></div></div>
  <div class="table-responsive"><table class="table"><thead><tr><th>ID</th><th>Customer</th><th>Contact</th><th>Active</th><th>Completed</th><th>Total Spent</th><th></th></tr></thead><tbody id="customerRows">${customerRows()}</tbody></table></div></div>`;
}
function customerRows(q = "") {
  const term = q.toLowerCase();
  return state.customers.filter(c => `${c.code} ${c.name} ${c.contact}`.toLowerCase().includes(term)).map(c =>
    `<tr><td>${esc(c.code)}</td><td><strong>${esc(c.name)}</strong><div class="small text-secondary">${esc(c.email)}</div></td><td>${esc(c.contact)}</td><td>${c.activeSessions}</td><td>${c.completedSessions}</td><td>${money(c.totalSpent)}</td><td class="text-end"><button class="btn btn-sm btn-outline-light" onclick="viewCustomer(${c.id})">View</button></td></tr>`
  ).join("") || `<tr><td colspan="7"><div class="empty">No customers found.</div></td></tr>`;
}

/* ---------------------------------------------------------------- computers */
function computersView() {
  return `<div class="d-flex justify-content-between mb-4"><div><p class="text-secondary mb-0">Monitor, assign, and maintain computer units.</p><div class="small text-secondary mt-1">${isAdmin() ? "Admin controls: add/remove units, change hourly rates and maintenance status. Sessions are handled by cashiers." : "Cashiers start and end customer sessions here."}</div></div>${isAdmin() ? `<div class="d-flex flex-wrap gap-2"><button class="btn btn-outline-light" onclick="openService()"><i class="bi bi-plus-circle me-2"></i>Add Service</button><button class="btn btn-primary" onclick="openComputer()"><i class="bi bi-plus-lg me-2"></i>Add Computer</button></div>` : ""}</div>
  <div class="row g-3">${state.computers.map(pc => pcCard(pc, false, true)).join("") || `<div class="empty">No computers found.</div>`}</div>`;
}

/* ----------------------------------------------------------------- sessions */
function sessionsView() {
  const f = state.sessionFilter;
  return `<div class="d-flex flex-wrap gap-2 justify-content-between mb-3"><div class="d-flex flex-wrap gap-2"><input id="sessionSearch" class="form-control" placeholder="Search customer, PC, session" style="width:280px" value="${esc(f.q)}"><select id="sessionStatus" class="form-select" style="width:150px"><option value="">All Status</option><option ${f.status === "Active" ? "selected" : ""}>Active</option><option value="Completed" ${f.status === "Completed" ? "selected" : ""}>Timed Out</option></select><input id="sessionDate" type="date" class="form-control session-date-filter" value="${esc(f.date)}" title="Filter by date"><select id="sessionSort" class="form-select" style="width:190px"><option value="date_desc" ${f.sort === "date_desc" ? "selected" : ""}>Newest first</option><option value="date_asc" ${f.sort === "date_asc" ? "selected" : ""}>Oldest first</option><option value="name_asc" ${f.sort === "name_asc" ? "selected" : ""}>Customer A–Z</option><option value="name_desc" ${f.sort === "name_desc" ? "selected" : ""}>Customer Z–A</option><option value="pc_asc" ${f.sort === "pc_asc" ? "selected" : ""}>PC A–Z</option></select></div>${isCashier() ? `<button class="btn btn-primary" onclick="openStartSession()"><i class="bi bi-play-circle me-2"></i>Start Session</button>` : ""}</div>
  <div class="panel"><div class="table-responsive"><table class="table"><thead><tr><th>Session</th><th>Customer</th><th>Computer</th><th>Start</th><th>End</th><th>Duration</th><th>Current/Final</th><th>Status</th><th></th></tr></thead><tbody id="sessionRows">${sessionRows()}</tbody></table></div></div>`;
}
function sortSessions() { const f = state.sessionFilter; const dateOnly = d => d ? new Date(d).toLocaleDateString("en-CA", { timeZone: PH_TZ }) : ""; if (f.date) state.sessions = state.sessions.filter(s => dateOnly(s.start) === f.date); const cmp = (a,b) => String(a||"").localeCompare(String(b||""), "en", { sensitivity:"base", numeric:true }); state.sessions.sort((a,b) => f.sort === "name_asc" ? cmp(a.customerName,b.customerName) : f.sort === "name_desc" ? cmp(b.customerName,a.customerName) : f.sort === "pc_asc" ? cmp(a.computerName,b.computerName) : f.sort === "date_asc" ? new Date(a.start)-new Date(b.start) : new Date(b.start)-new Date(a.start)); }
function sortBilling() { const f = state.billingFilter; const cmp = (a,b) => String(a||"").localeCompare(String(b||""), "en", { sensitivity:"base", numeric:true }); state.sessions.sort((a,b) => f.sort === "name_asc" ? cmp(a.customerName,b.customerName) : f.sort === "name_desc" ? cmp(b.customerName,a.customerName) : f.sort === "amount_desc" ? Number(b.totalAmount)-Number(a.totalAmount) : f.sort === "date_asc" ? new Date(a.start)-new Date(b.start) : new Date(b.start)-new Date(a.start)); }

function sessionRows() {
  return state.sessions.map(s => {
    const active = s.status === "Active";
    let action = "";
    if (active && isCashier()) action = `<button class="btn btn-sm btn-danger" onclick="openEndSession(${s.id})">End</button>`;
    else if (!active) action = `<button class="btn btn-sm btn-outline-light" onclick="showReceipt(${s.id})">View</button>`;
    return `<tr><td>${esc(s.code)}</td><td>${esc(s.customerName)}</td><td>${esc(s.computerName)}</td><td>${fmtDT(s.start)}</td><td>${fmtDT(s.end)}</td><td>${active ? (s.timerMode === "fixed" ? `<span class="live-rem" data-session="${s.id}">${clockText(liveRemaining(s))}</span>` : `<span class="live-dur" data-session="${s.id}">${clockText(liveSeconds(s))}</span>`) : durText(s.durationSeconds)}</td><td>${active ? `<span class="live-cost" data-session="${s.id}">${money(liveAmount(s))}</span>` : money(s.totalAmount)}</td><td>${active ? statusBadge("Active") : `<span class="badge badge-soft status-maint">Timed Out</span>`}</td><td class="text-end">${action}</td></tr>`;
  }).join("") || `<tr><td colspan="9"><div class="empty">No sessions found.</div></td></tr>`;
}
let sessionSearchTimer = null;
async function reloadSessionRows() {
  try {
    await loadData("sessions");
    $("#sessionRows").innerHTML = sessionRows();
  } catch (e) { toast(e.message, "danger"); }
}

/* ------------------------------------------------------------------ billing */
function billingView() {
  const f = state.billingFilter;
  const rows = state.sessions.map(s => {
    let action = `<span class="text-secondary small">—</span>`;
    if (s.paid) action = `<button class="btn btn-sm btn-outline-light" onclick="showReceipt(${s.id})">Receipt</button>`;
    else action = isCashier() ? `<button class="btn btn-sm btn-primary" onclick="openPayment(${s.id})">Collect</button>` : `<span class="badge badge-soft status-maint">Pending</span>`;
    return `<tr><td>${esc(s.code)}</td><td>${esc(s.customerName)}</td><td>${esc(s.computerName)}</td><td>${fmtDT(s.end)}</td><td>${durText(s.durationSeconds)}</td><td>${money(s.rentalAmount)}</td><td>${money(s.servicesAmount)}</td><td>${money(s.additionalFeeAmount || 0)}</td><td><strong>${money(s.totalAmount)}</strong></td><td>${s.paid ? statusBadge("Paid") : `<span class="badge badge-soft status-maint">Timed Out</span>`}</td><td class="text-end">${action}</td></tr>`;
  }).join("");
  return `<div class="d-flex flex-wrap gap-2 justify-content-between mb-3"><div class="d-flex flex-wrap gap-2"><input id="billingSearch" class="form-control" placeholder="Search name or session" style="width:280px" value="${esc(f.q)}"><select id="billingSort" class="form-select" style="width:190px"><option value="date_desc" ${f.sort === "date_desc" ? "selected" : ""}>Newest first</option><option value="date_asc" ${f.sort === "date_asc" ? "selected" : ""}>Oldest first</option><option value="name_asc" ${f.sort === "name_asc" ? "selected" : ""}>Customer A–Z</option><option value="name_desc" ${f.sort === "name_desc" ? "selected" : ""}>Customer Z–A</option><option value="amount_desc" ${f.sort === "amount_desc" ? "selected" : ""}>Highest bill</option></select></div></div>
  <div class="panel"><div class="table-responsive"><table class="table"><thead><tr><th>Session</th><th>Customer</th><th>Computer</th><th>Ended</th><th>Duration</th><th>Rental</th><th>Services</th><th>Additional Fee</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody id="billingRows">${rows || `<tr><td colspan="11"><div class="empty">No billing records found.</div></td></tr>`}</tbody></table></div></div>`;
}

/* ----------------------------------------------------------------- services */
function servicesView() {
  return `<div class="d-flex justify-content-between mb-4"><p class="text-secondary mb-0">Optional services attached to sessions.</p>${isAdmin() ? `<button class="btn btn-primary" onclick="openService()"><i class="bi bi-plus-lg me-2"></i>Add Service</button>` : ""}</div>
  <div class="panel"><div class="table-responsive"><table class="table"><thead><tr><th>ID</th><th>Service</th><th>Price</th><th>Unit</th><th>Usage</th></tr></thead><tbody>${state.services.map(s => `<tr><td>${esc(s.code)}</td><td>${esc(s.name)}</td><td>${money(s.price)}</td><td>per ${esc(s.unit)}</td><td>${s.usage}</td></tr>`).join("") || `<tr><td colspan="5"><div class="empty">No services yet.</div></td></tr>`}</tbody></table></div></div>`;
}

/* -------------------------------------------------------------------- users */
function usersView() {
  const rows = state.users.map(u => {
    const self = u.id === state.user.id;
    return `<tr><td><strong>${esc(u.username)}</strong>${self ? ` <span class="small text-secondary">(you)</span>` : ""}</td><td>${u.role === "admin" ? "Administrator" : "Cashier"}</td><td>${u.isActive ? `<span class="badge badge-soft status-available">Active</span>` : `<span class="badge badge-soft status-maint">Disabled</span>`}</td><td>${u.role === "admin" ? "Statistics, reports, computers, services, users" : "Sessions, customers, payments"}</td><td class="text-end"><button class="btn btn-sm btn-outline-light" onclick="openResetPassword(${u.id})">Reset Password</button> ${self ? "" : `<button class="btn btn-sm ${u.isActive ? "btn-outline-danger" : "btn-outline-light"}" onclick="toggleUser(${u.id},${u.isActive ? "false" : "true"})">${u.isActive ? "Disable" : "Enable"}</button>`}</td></tr>`;
  }).join("");
  return `<div class="d-flex justify-content-between mb-4"><p class="text-secondary mb-0">Staff accounts and roles. Customers do not have accounts.</p><button class="btn btn-primary" onclick="openUser()"><i class="bi bi-person-plus me-2"></i>Add User</button></div>
  <div class="panel"><div class="table-responsive"><table class="table"><thead><tr><th>User</th><th>Role</th><th>Status</th><th>Access</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div>`;
}
function openUser() {
  modal("Add Staff Account", `<form id="userForm" onsubmit="return false"><div class="row g-3"><div class="col-md-6"><label class="form-label">Username *</label><input id="uName" class="form-control" maxlength="50" autocomplete="off"></div><div class="col-md-6"><label class="form-label">Role *</label><select id="uRole" class="form-select"><option value="cashier">Cashier</option><option value="admin">Administrator</option></select></div><div class="col-12"><label class="form-label">Password * <span class="text-secondary small">(at least 8 characters)</span></label><input id="uPass" type="password" class="form-control" autocomplete="new-password"></div></div></form>`,
    `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveUser(this)">Create Account</button>`).show();
}
async function saveUser(btn) {
  await guarded(btn, async () => {
    await api("/users", { method: "POST", body: { username: $("#uName").value, role: $("#uRole").value, password: $("#uPass").value } });
    await hideModal(); toast("Staff account created"); render("users");
  });
}
async function toggleUser(id, active) {
  try { await api(`/users/${id}`, { method: "PATCH", body: { isActive: active } }); toast(active ? "Account enabled" : "Account disabled"); render("users"); }
  catch (e) { toast(e.message, "danger"); }
}
function openResetPassword(id) {
  const u = state.users.find(x => x.id === id);
  modal(`Reset Password — ${esc(u.username)}`, `<label class="form-label">New password * <span class="text-secondary small">(at least 8 characters)</span></label><input id="newPass" type="password" class="form-control" autocomplete="new-password">`,
    `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="savePassword(${id},this)">Save Password</button>`).show();
}
async function savePassword(id, btn) {
  await guarded(btn, async () => {
    await api(`/users/${id}`, { method: "PATCH", body: { password: $("#newPass").value } });
    await hideModal(); toast("Password updated");
  });
}

/* ------------------------------------------------------------------- modals */
function modal(title, body, footer = "") {
  const el = $("#modal");
  el.querySelector(".modal-content").innerHTML = `<div class="modal-header"><h5 class="modal-title">${title}</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body">${body}</div>${footer ? `<div class="modal-footer">${footer}</div>` : ""}`;
  return bootstrap.Modal.getOrCreateInstance(el);
}
function hideModal() {
  return new Promise(resolve => {
    const el = $("#modal"), inst = bootstrap.Modal.getInstance(el);
    if (!inst || !el.classList.contains("show")) { resolve(); return; }
    el.addEventListener("hidden.bs.modal", () => resolve(), { once: true });
    inst.hide();
  });
}
/* run an action behind a button: disables it while working and shows API errors as a toast */
async function guarded(btn, fn) {
  if (btn) btn.disabled = true;
  try { await fn(); }
  catch (e) { toast(e.message, "danger"); if (e.status === 409 || e.status === 404) render(state.page, true); }
  finally { if (btn) btn.disabled = false; }
}

/* --------------------------------------------------------------- customers */
function openCustomer() {
  if (!isCashier()) { toast("Only cashiers can register customers.", "danger"); return; }
  modal("Register Customer", `<form id="customerForm" onsubmit="return false"><div class="row g-3"><div class="col-md-6"><label class="form-label">First Name *</label><input id="cFirstName" class="form-control" maxlength="60" required></div><div class="col-md-6"><label class="form-label">Last Name *</label><input id="cLastName" class="form-control" maxlength="60" required></div><div class="col-md-6"><label class="form-label">Contact Number</label><div class="input-group"><span class="input-group-text">+63</span><input id="cContact" class="form-control" inputmode="numeric" maxlength="10" placeholder="917 123 4567"></div><div class="small text-secondary mt-1">Philippine mobile number</div></div><div class="col-md-6"><label class="form-label">Email</label><input id="cEmail" type="email" class="form-control" maxlength="100"></div></div></form>`,
    `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveCustomer(this)">Save Customer</button>`).show();
}
async function saveCustomer(btn) {
  const firstName = $("#cFirstName").value.trim(), lastName = $("#cLastName").value.trim();
  const digits = $("#cContact").value.replace(/\D/g, "");
  const contact = digits ? `+63 ${digits.slice(0,3)} ${digits.slice(3,6)} ${digits.slice(6,10)}`.trim() : "";
  if (!firstName || !lastName) { toast("First name and last name are required.", "danger"); return; }
  if (digits && !/^9\d{9}$/.test(digits)) { toast("Enter a valid Philippine mobile number.", "danger"); return; }
  await guarded(btn, async () => {
    const c = await api("/customers", { method: "POST", body: { firstName, lastName, contact, email: $("#cEmail").value.trim() } });
    await hideModal(); toast(`Customer ${c.code} registered successfully`); render("customers");
  });
}
async function viewCustomer(id) {
  let c;
  try { c = await api(`/customers/${id}`); } catch (e) { toast(e.message, "danger"); return; }
  indexSessions(c.sessions);
  const body = `<div class="row g-3 mb-3"><div class="col-md-6"><div class="quick"><div class="small text-secondary">Customer</div><strong>${esc(c.name)}</strong> <span class="text-secondary small">${esc(c.code)}</span><div>${esc(c.contact)}</div><div>${esc(c.email)}</div></div></div><div class="col-md-6"><div class="quick"><div class="small text-secondary">Summary</div><strong>${c.sessions.length} sessions</strong><div>${money(c.totalSpent)} total spent</div>${c.activeSessions ? `<div class="mt-1">Currently active</div>` : ""}</div></div></div>
  <h6>Session History</h6><div class="table-responsive"><table class="table"><thead><tr><th>Session</th><th>PC</th><th>Date</th><th>Duration</th><th>Total</th><th>Status</th></tr></thead><tbody>${c.sessions.map(s => `<tr><td>${esc(s.code)}</td><td>${esc(s.computerName)}</td><td>${fmtDT(s.start)}</td><td>${s.status === "Active" ? `<span class="live-dur" data-session="${s.id}">${clockText(s.durationSeconds)}</span>` : durText(s.durationSeconds)}</td><td>${money(s.totalAmount)}</td><td>${statusBadge(s.status)}</td></tr>`).join("") || `<tr><td colspan="6"><div class="empty">No sessions yet.</div></td></tr>`}</tbody></table></div>`;
  modal(`Customer Profile — ${esc(c.name)}`, body, `<button class="btn btn-outline-light" data-bs-dismiss="modal">Close</button>`).show();
}

/* --------------------------------------------------------------- computers */
function openComputer() {
  modal("Add Computer Unit", `<form onsubmit="return false"><div class="row g-3"><div class="col-md-6"><label class="form-label">Computer ID *</label><input id="pcId" class="form-control" placeholder="PC-09" maxlength="30"></div><div class="col-md-6"><label class="form-label">Hourly Rate *</label><input id="pcRate" type="number" min="0.01" step=".01" class="form-control" value="15"></div></div></form>`,
    `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveComputer(this)">Add Computer</button>`).show();
}
async function saveComputer(btn) {
  const name = $("#pcId").value.trim(), rate = Number($("#pcRate").value);
  if (!name || !(rate > 0)) { toast("Computer ID and a valid rate are required.", "danger"); return; }
  await guarded(btn, async () => {
    await api("/computers", { method: "POST", body: { name, hourlyRate: rate } });
    await hideModal(); toast("Computer added"); render("computers");
  });
}
function openEditComputer(id) {
  const pc = state.computers.find(c => c.id === id);
  if (!pc) return;
  modal(`Edit ${esc(pc.name)}`, `<label class="form-label">Hourly Rate</label><input id="editPcRate" type="number" min="0.01" step=".01" class="form-control" value="${pc.rate}"><div class="small text-secondary mt-2">Current status: ${esc(pc.status)} · A new rate applies to sessions started from now on.</div>`,
    `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveEditedComputer(${id},this)">Save Rate</button>`).show();
}
async function saveEditedComputer(id, btn) {
  const rate = Number($("#editPcRate").value);
  if (!(rate > 0)) { toast("Enter a valid hourly rate.", "danger"); return; }
  await guarded(btn, async () => {
    await api(`/computers/${id}`, { method: "PATCH", body: { hourlyRate: rate } });
    await hideModal(); toast(`Rate updated to ${money(rate)}/hour`); render("computers");
  });
}
async function removeComputer(id) {
  const pc = state.computers.find(c => c.id === id);
  if (!pc || !confirm(`Remove ${pc.name} from the computer inventory?`)) return;
  try { await api(`/computers/${id}`, { method: "DELETE" }); toast(`${pc.name} removed`); render("computers"); }
  catch (e) { toast(e.message, "danger"); }
}
function changeComputerStatus(id) {
  const pc = state.computers.find(c => c.id === id);
  if (!pc) return;
  if (pc.activeSession) { toast("An active session must be ended by the cashier first.", "danger"); return; }
  modal(`Update ${esc(pc.name)}`, `<label class="form-label">Status</label><select id="pcStatus" class="form-select"><option>Available</option><option>Maintenance</option></select>`,
    `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveComputerStatus(${id},this)">Save</button>`).show();
  $("#pcStatus").value = pc.status === "Maintenance" ? "Maintenance" : "Available";
}
async function saveComputerStatus(id, btn) {
  await guarded(btn, async () => {
    await api(`/computers/${id}`, { method: "PATCH", body: { status: $("#pcStatus").value } });
    await hideModal(); toast("Computer status updated"); render("computers");
  });
}

function adjustDuration(delta) { const el = $("#durationMinutes"); if (el) el.value = Math.min(1440, Math.max(30, Number(el.value || 30) + delta)); }

/* ------------------------------------------------------------ start session */
async function openStartSession(preferredPc = 0) {
  if (!isCashier()) { toast("Only cashiers can start sessions.", "danger"); return; }
  try {
    const [computers, customers] = await Promise.all([api("/computers"), api("/customers")]);
    state.computers = computers; state.customers = customers;
  } catch (e) { toast(e.message, "danger"); return; }
  const available = state.computers.filter(c => c.status === "Available");
  if (!available.length) { toast("No available computers right now.", "danger"); render(state.page, true); return; }
  const body = `<form id="startForm" onsubmit="return false">
    <label class="form-label">Customer Type *</label>
    <div class="btn-group w-100 mb-3" role="group">
      <input type="radio" class="btn-check" name="custType" id="typeGuest" value="guest" checked><label class="btn btn-outline-primary" for="typeGuest"><i class="bi bi-person me-1"></i>Guest</label>
      <input type="radio" class="btn-check" name="custType" id="typeExisting" value="existing"><label class="btn btn-outline-primary" for="typeExisting"><i class="bi bi-person-check me-1"></i>Existing Customer</label>
    </div>
    <div class="row g-3">
      <div class="col-md-7">
        <div id="guestBox"><label class="form-label">Guest Name <span class="text-secondary small">(optional)</span></label><input id="guestName" class="form-control" maxlength="100" placeholder="Walk-in customer"></div>
        <div id="existingBox" class="d-none"><label class="form-label">Customer *</label><input id="customerFilter" class="form-control mb-2" placeholder="Search name, ID, or contact"><select id="sessionCustomer" class="form-select" size="5"></select></div>
      </div>
      <div class="col-md-5"><label class="form-label">Computer *</label><select id="sessionPc" class="form-select">${available.map(c => `<option value="${c.id}" ${c.id === preferredPc ? "selected" : ""}>${esc(c.name)} — ${money(c.rate)}/hr</option>`).join("")}</select></div>
      <div class="col-md-7"><label class="form-label">Session Time *</label><select id="timerMode" class="form-select"><option value="open">Open Time — runs until manually ended</option><option value="fixed">Fixed Time — auto timeout</option></select></div>
      <div id="fixedTimeBox" class="col-md-5 d-none"><label class="form-label">Duration</label><div class="input-group"><button type="button" class="btn btn-outline-light" onclick="adjustDuration(-30)">− 30</button><input id="durationMinutes" type="number" class="form-control text-center" value="30" min="30" max="1440" step="30"><span class="input-group-text">min</span><button type="button" class="btn btn-outline-light" onclick="adjustDuration(30)">+ 30</button></div><div class="small text-secondary mt-1">30-minute increments, up to 24 hours.</div></div>
    </div>
    <div class="quick mt-3"><i class="bi bi-info-circle me-2"></i>Open Time runs until manually ended. Fixed Time automatically ends when the selected time expires.</div></form>`;
  modal("Start Customer Session", body, `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="startSession(this)">Start Session</button>`).show();

  const fill = () => {
    const term = $("#customerFilter").value.trim().toLowerCase();
    const list = state.customers.filter(c => `${c.code} ${c.name} ${c.contact}`.toLowerCase().includes(term));
    $("#sessionCustomer").innerHTML = list.map(c => `<option value="${c.id}">${esc(c.name)} — ${esc(c.code)}</option>`).join("") || `<option value="" disabled>No matching customers</option>`;
  };
  fill();
  $("#customerFilter").addEventListener("input", fill);
  $("#timerMode").addEventListener("change", () => $("#fixedTimeBox").classList.toggle("d-none", $("#timerMode").value !== "fixed"));
  document.querySelectorAll("input[name=custType]").forEach(r => r.addEventListener("change", () => {
    const existing = $("#typeExisting").checked;
    $("#existingBox").classList.toggle("d-none", !existing);
    $("#guestBox").classList.toggle("d-none", existing);
  }));
}
async function startSession(btn) {
  const existing = $("#typeExisting").checked, pc = Number($("#sessionPc").value);
  const timerMode = $("#timerMode").value;
  const durationMinutes = Number($("#durationMinutes")?.value || 30);
  if (timerMode === "fixed" && (!Number.isInteger(durationMinutes) || durationMinutes < 30 || durationMinutes % 30 !== 0 || durationMinutes > 1440)) { toast("Fixed time must be a multiple of 30 minutes (30–1440).", "danger"); return; }
  const body = { computerId: pc, customerType: existing ? "existing" : "guest", timerMode };
  if (timerMode === "fixed") body.durationMinutes = durationMinutes;
  if (existing) {
    const cid = Number($("#sessionCustomer").value);
    if (!cid) { toast("Select an existing customer, or choose Guest.", "danger"); return; }
    body.customerId = cid;
  } else {
    body.guestName = $("#guestName").value.trim();
  }
  await guarded(btn, async () => {
    const s = await api("/sessions/start", { method: "POST", body });
    await hideModal(); toast(`Session ${s.code} started on ${s.computerName}`); render("dashboard");
  });
}

/* ----------------------------------------------- add service during session */
async function openAddActiveService(id) {
  if (!isCashier()) { toast("Only cashiers can add services to an active session.", "danger"); return; }
  let session, services;
  try { [session, services] = await Promise.all([api(`/sessions/${id}`), api("/services")]); }
  catch (e) { toast(e.message, "danger"); return; }
  if (session.status !== "Active") { toast("This session is no longer active.", "danger"); await render("computers", true); return; }
  if (!services.length) { toast("No active services are available. Ask an admin to add services first.", "danger"); return; }
  state.services = services;
  const body = `<div class="quick mb-3"><div class="small text-secondary">Active session</div><strong>${esc(session.customerName)}</strong><div>${esc(session.computerName)} · ${esc(session.code)}</div><div class="small text-secondary mt-1">The PC timer will continue running. This charge will be added to the final bill.</div></div>
    <form onsubmit="return false"><label class="form-label">Service *</label><select id="activeServiceId" class="form-select mb-3" onchange="updateActiveServiceTotal()">${services.map(x => `<option value="${x.id}" data-price="${Number(x.price)}">${esc(x.name)} — ${money(x.price)} per ${esc(x.unit)}</option>`).join("")}</select><label class="form-label">Quantity *</label><input id="activeServiceQty" type="number" class="form-control mb-3" min="1" max="1000" step="1" value="1" oninput="updateActiveServiceTotal()"><div class="quick d-flex justify-content-between"><span>Service charge</span><strong id="activeServiceTotal">${money(services[0].price)}</strong></div></form>`;
  modal(`Add Service — ${esc(session.code)}`, body, `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveActiveService(${id}, this)">Add to Final Bill</button>`).show();
}
function updateActiveServiceTotal() {
  const select = $("#activeServiceId"), qty = $("#activeServiceQty"), total = $("#activeServiceTotal");
  if (!select || !qty || !total) return;
  const price = Number(select.selectedOptions[0]?.dataset.price || 0);
  const quantity = Math.max(1, Math.min(1000, Math.floor(Number(qty.value) || 1)));
  total.textContent = money(price * quantity);
}
async function saveActiveService(id, btn) {
  const serviceId = Number($("#activeServiceId")?.value);
  const quantity = Number($("#activeServiceQty")?.value);
  if (!serviceId || !Number.isInteger(quantity) || quantity < 1 || quantity > 1000) { toast("Choose a service and enter a quantity from 1 to 1000.", "danger"); return; }
  await guarded(btn, async () => {
    const updated = await api(`/sessions/${id}/services`, { method: "POST", body: { serviceId, quantity } });
    await hideModal();
    toast(`${money(updated.servicesAmount)} in service charges now attached to ${updated.code}.`);
    await render("computers", true);
  });
}

/* -------------------------------------------------------------- end session */
async function openEndSession(id) {
  if (!isCashier()) { toast("Only cashiers can end sessions.", "danger"); return; }
  let s;
  try {
    const [session, services] = await Promise.all([api(`/sessions/${id}`), api("/services")]);
    s = session; state.services = services;
  } catch (e) { toast(e.message, "danger"); return; }
  if (s.status !== "Active") { toast("This session has already ended.", "danger"); render(state.page, true); return; }
  s._at = performance.now();
  endCtx = { session: s, lines: [] };
  const body = `<div class="row g-3"><div class="col-md-6"><div class="quick"><div class="small text-secondary">Customer</div><strong>${esc(s.customerName)}</strong><div>${esc(s.computerName)}</div><div>Started ${fmtTime(s.start)}</div></div></div>
    <div class="col-md-6"><div class="quick"><div class="small text-secondary">Current total (estimate)</div><strong class="fs-4" id="endTotal">${money(0)}</strong><div id="endDur"></div></div></div></div>
    <hr>${s.services.length ? `<div class="quick mb-3"><strong>Services already added during this session</strong>${s.services.map(x => `<div class="d-flex justify-content-between small mt-1"><span>${esc(x.name)} × ${x.quantity}</span><span>${money(x.lineTotal)}</span></div>`).join("")}</div>` : ""}<div class="d-flex justify-content-between align-items-center mb-2"><strong>Additional Session Services</strong><button class="btn btn-sm btn-outline-light" onclick="addEndLine()" ${state.services.length ? "" : "disabled"}><i class="bi bi-plus"></i> Add Service</button></div><div id="serviceLines"></div>
    <hr><strong>Additional Fee (optional)</strong><div class="row g-2 mt-1"><div class="col-md-5"><label class="form-label small">Fee amount (₱)</label><input id="additionalFee" type="number" min="0" max="100000" step=".01" class="form-control" value="0" oninput="updateEndTotals()"></div><div class="col-md-7"><label class="form-label small">Description</label><input id="additionalFeeNote" maxlength="200" class="form-control" placeholder="e.g., miscellaneous charge"></div></div>
    <div class="text-secondary small mt-3">Ending the session stops the timer, makes the computer available again and creates the final bill. Additional fees are recorded directly on the session, without a separate table. Payment is collected next.</div>`;
  modal(`End Session — ${esc(s.code)}`, body, `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-danger" onclick="finishSession(this)">End Session & Create Bill</button>`).show();
  $("#modal").addEventListener("hidden.bs.modal", () => { endCtx = null; }, { once: true });
  renderEndLines(); updateEndTotals();
}
function renderEndLines() {
  const box = $("#serviceLines"); if (!box || !endCtx) return;
  box.innerHTML = endCtx.lines.length ? endCtx.lines.map((l, i) => `<div class="row g-2 align-items-end mb-2"><div class="col-md-7"><label class="form-label small">Service</label><select class="form-select" onchange="setEndLine(${i},'serviceId',this.value)">${state.services.map(sv => `<option value="${sv.id}" ${sv.id === l.serviceId ? "selected" : ""}>${esc(sv.name)} — ${money(sv.price)}/${esc(sv.unit)}</option>`).join("")}</select></div><div class="col-md-3"><label class="form-label small">Quantity</label><input type="number" min="1" max="1000" class="form-control" value="${l.qty}" oninput="setEndLine(${i},'qty',this.value)"></div><div class="col-md-2"><button class="btn btn-outline-danger w-100" onclick="removeEndLine(${i})"><i class="bi bi-trash"></i></button></div></div>`).join("") : `<div class="empty">No additional services.</div>`;
}
function addEndLine() { if (!endCtx || !state.services.length) return; endCtx.lines.push({ serviceId: state.services[0].id, qty: 1 }); renderEndLines(); updateEndTotals(); }
function removeEndLine(i) { if (!endCtx) return; endCtx.lines.splice(i, 1); renderEndLines(); updateEndTotals(); }
function setEndLine(i, key, v) {
  if (!endCtx || !endCtx.lines[i]) return;
  endCtx.lines[i][key === "qty" ? "qty" : "serviceId"] = key === "qty" ? Math.max(1, Math.min(1000, Math.floor(Number(v)) || 1)) : Number(v);
  updateEndTotals();
}
function updateEndTotals() {
  const t = $("#endTotal"); if (!t || !endCtx) return;
  const s = endCtx.session;
  const rentalC = Math.round(liveSeconds(s) * Math.round(s.rate * 100) / 3600);
  const svcC = endCtx.lines.reduce((a, l) => { const sv = state.services.find(x => x.id === l.serviceId); return a + (sv ? Math.round(sv.price * 100) * l.qty : 0); }, 0);
  const feeC = Math.round(Math.max(0, Number($("#additionalFee")?.value || 0)) * 100);
  t.textContent = money((rentalC + Math.round(Number(s.servicesAmount || 0) * 100) + svcC + feeC) / 100);
  $("#endDur").textContent = `${clockText(liveSeconds(s))} · ${money(s.rate)}/hr`;
}
async function finishSession(btn) {
  if (!endCtx) return;
  const id = endCtx.session.id;
  const services = endCtx.lines.map(l => ({ serviceId: l.serviceId, quantity: l.qty }));
  const additionalFee = Number($("#additionalFee")?.value || 0);
  const additionalFeeNote = ($("#additionalFeeNote")?.value || "").trim();
  if (!Number.isFinite(additionalFee) || additionalFee < 0 || Math.round(additionalFee * 100) !== additionalFee * 100) { toast("Enter a valid additional fee.", "danger"); return; }
  if (additionalFee > 0 && !additionalFeeNote) { toast("Enter a description for the additional fee.", "danger"); return; }
  await guarded(btn, async () => {
    const done = await api(`/sessions/${id}/end`, { method: "POST", body: { services, additionalFee, additionalFeeNote } });
    await hideModal();
    toast(`Session ${done.code} completed. Bill: ${money(done.totalAmount)}`);
    await render("billing");
    openPayment(done.id);
  });
}

/* ------------------------------------------------------------------ payment */
async function openPayment(id) {
  if (!isCashier()) { toast("Only cashiers can collect payments.", "danger"); return; }
  let s;
  try { s = await api(`/sessions/${id}`); } catch (e) { toast(e.message, "danger"); return; }
  if (s.status !== "Completed") { toast("End the session before collecting payment.", "danger"); return; }
  if (s.paid) { toast("This session has already been paid.", "danger"); showReceipt(id); return; }
  const total = s.totalAmount;
  const body = `<div class="quick mb-3"><div class="d-flex justify-content-between"><span>Computer rental (${durText(s.durationSeconds)} · ${esc(s.computerName)})</span><strong>${money(s.rentalAmount)}</strong></div><div class="d-flex justify-content-between"><span>Services</span><strong>${money(s.servicesAmount)}</strong></div>${Number(s.additionalFeeAmount || 0) > 0 ? `<div class="d-flex justify-content-between"><span>${esc(s.additionalFeeNote || "Additional fee")}</span><strong>${money(s.additionalFeeAmount)}</strong></div>` : ""}<hr><div class="d-flex justify-content-between fs-5"><strong>Total</strong><strong>${money(total)}</strong></div></div>
  <form onsubmit="return false"><div class="row g-3"><div class="col-md-5"><label class="form-label">Payment Method *</label><select id="payMethod" class="form-select"><option>Cash</option><option>GCash</option><option>Card</option></select></div><div class="col-md-7"><label class="form-label">Amount Received *</label><input id="amountReceived" type="number" min="${total}" step=".01" class="form-control" value="${total.toFixed(2)}"><div class="small text-secondary mt-1">For non-cash methods, enter the exact amount.</div></div></div><div class="quick mt-3"><div class="d-flex justify-content-between"><span>Change</span><strong id="changeValue">${money(0)}</strong></div></div></form>`;
  modal(`Collect Payment — ${esc(s.code)}`, body, `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="recordPayment(${id},${total},this)">Confirm Payment</button>`).show();
  const update = () => { const amt = Number($("#amountReceived").value) || 0; $("#changeValue").textContent = money(Math.max(0, Math.round((amt - total) * 100) / 100)); };
  $("#amountReceived").addEventListener("input", update);
  $("#payMethod").addEventListener("change", () => { if ($("#payMethod").value !== "Cash") { $("#amountReceived").value = total.toFixed(2); update(); } });
  update();
}
async function recordPayment(id, total, btn) {
  const method = $("#payMethod").value, received = Number($("#amountReceived").value);
  if (!(received >= total)) { toast("Amount received cannot be less than the total.", "danger"); return; }
  if (method !== "Cash" && Math.abs(received - total) > 0.009) { toast("GCash/Card must use the exact bill amount.", "danger"); return; }
  await guarded(btn, async () => {
    const s = await api("/transactions", { method: "POST", body: { sessionId: id, paymentMethod: method, paymentAmount: received } });
    await hideModal();
    toast(`Payment ${s.transaction.code} recorded`);
    render(state.page, true);
    showReceipt(id);
  });
}
async function showReceipt(id) {
  let s;
  try { s = await api(`/sessions/${id}`); } catch (e) { toast(e.message, "danger"); return; }
  if (s.status !== "Completed") { toast("This session is still running.", "danger"); return; }
  const p = s.transaction;
  const serviceRows = s.services.map(x => `<div class="d-flex justify-content-between"><span>${esc(x.name)} × ${x.quantity}</span><span>${money(x.lineTotal)}</span></div>`).join("");
  const body = `<div class="receipt" id="receipt"><div class="text-center"><h4>CyberCafe</h4><div class="small">Computer Rental & Internet Café</div><hr><strong>RECEIPT ${p ? esc(p.code) : "UNPAID"}</strong></div><div class="mt-3"><div>Customer: <strong>${esc(s.customerName)}</strong></div><div>Session: ${esc(s.code)}</div><div>Computer: ${esc(s.computerName)}</div><div>Time: ${fmtTime(s.start)} – ${fmtTime(s.end)} (${durText(s.durationSeconds)})</div><div>Date: ${fmtDate(s.end)}</div></div><hr><div class="d-flex justify-content-between"><span>Computer rental @ ${money(s.rate)}/hr</span><span>${money(s.rentalAmount)}</span></div>${serviceRows ? `<div class="mt-2">${serviceRows}</div>` : ""}${Number(s.additionalFeeAmount || 0) > 0 ? `<div class="d-flex justify-content-between mt-2"><span>${esc(s.additionalFeeNote || "Additional fee")}</span><span>${money(s.additionalFeeAmount)}</span></div>` : ""}<hr><div class="d-flex justify-content-between fs-5"><strong>TOTAL</strong><strong>${money(s.totalAmount)}</strong></div>${p ? `<hr><div class="d-flex justify-content-between"><span>Payment</span><span>${esc(p.method)}</span></div><div class="d-flex justify-content-between"><span>Received</span><span>${money(p.received)}</span></div><div class="d-flex justify-content-between"><span>Change</span><span>${money(p.change)}</span></div>` : `<div class="alert alert-warning mt-3 mb-0">Payment pending</div>`}</div>`;
  modal("Receipt", body, `<button class="btn btn-outline-light" data-bs-dismiss="modal">Close</button><button class="btn btn-primary" onclick="printReceipt()">Print Receipt</button>`).show();
}
function printReceipt() {
  const r = $("#receipt");
  const w = window.open("", "_blank", "width=600,height=800");
  if (!w) { toast("Allow pop-ups to print the receipt.", "danger"); return; }
  w.document.write(`<html><head><title>CyberCafe Receipt</title><style>body{font-family:Arial;padding:30px}.receipt{max-width:480px;margin:auto}.d-flex{display:flex}.justify-content-between{justify-content:space-between}.text-center{text-align:center}.mt-2{margin-top:8px}.mt-3{margin-top:16px}hr{border:0;border-top:1px solid #ccc}</style></head><body>${r.outerHTML}</body></html>`);
  w.document.close(); w.focus(); w.print();
}

/* ----------------------------------------------------------------- services */
function openService() {
  modal("Add Service", `<form onsubmit="return false"><label class="form-label">Service Name *</label><input id="svcName" class="form-control mb-3" maxlength="100"><label class="form-label">Price *</label><input id="svcPrice" type="number" min="0.01" step=".01" class="form-control mb-3"><label class="form-label">Unit</label><select id="svcUnit" class="form-select"><option>page</option><option>item</option><option>service</option></select></form>`,
    `<button class="btn btn-outline-light" data-bs-dismiss="modal">Cancel</button><button class="btn btn-primary" onclick="saveService(this)">Add Service</button>`).show();
}
async function saveService(btn) {
  const name = $("#svcName").value.trim(), price = Number($("#svcPrice").value);
  if (!name || !(price > 0)) { toast("Enter a service name and positive price.", "danger"); return; }
  await guarded(btn, async () => {
    await api("/services", { method: "POST", body: { name, price, unit: $("#svcUnit").value } });
    await hideModal(); toast("Service added"); render("services");
  });
}

/* ------------------------------------------------------------ page events etc */
function attachPageEvents(page, silent) {
  if (page === "customers") $("#customerSearch")?.addEventListener("input", e => $("#customerRows").innerHTML = customerRows(e.target.value));
  if (page === "sessions") {
    $("#sessionSearch").addEventListener("input", e => {
      state.sessionFilter.q = e.target.value;
      clearTimeout(sessionSearchTimer);
      sessionSearchTimer = setTimeout(reloadSessionRows, 300);
    });
    $("#sessionStatus").addEventListener("change", e => { state.sessionFilter.status = e.target.value; reloadSessionRows(); });
    $("#sessionDate").addEventListener("change", e => { state.sessionFilter.date = e.target.value; reloadSessionRows(); });
    $("#sessionSort").addEventListener("change", e => { state.sessionFilter.sort = e.target.value; sortSessions(); $("#sessionRows").innerHTML = sessionRows(); });
  }
  if (page === "billing") {
    $("#billingSearch").addEventListener("input", e => { state.billingFilter.q = e.target.value; clearTimeout(window.billingSearchTimer); window.billingSearchTimer = setTimeout(() => render("billing", true), 300); });
    $("#billingSort").addEventListener("change", e => { state.billingFilter.sort = e.target.value; render("billing", true); });
  }
  if (page === "dashboard") {
    $("#rangeSel")?.addEventListener("change", e => { state.range = Number(e.target.value); render("dashboard"); });
    drawCharts(!silent);
  }
}

function toast(msg, type = "success") {
  const d = document.createElement("div");
  d.className = `toast align-items-center text-bg-${type} border-0 position-fixed bottom-0 end-0 m-4`;
  d.style.zIndex = 2000;
  d.innerHTML = `<div class="d-flex"><div class="toast-body">${esc(msg)}</div><button class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button></div>`;
  document.body.appendChild(d);
  const t = new bootstrap.Toast(d, { delay: type === "danger" ? 4500 : 2600 });
  t.show();
  d.addEventListener("hidden.bs.toast", () => d.remove());
}

/* ------------------------------------------------------------ login / logout */
function enterApp(user) {
  state.user = user;
  $("#roleText").textContent = user.role === "admin" ? "Administrator" : "Cashier";
  $("#currentUser").textContent = user.username;
  document.querySelectorAll(".admin-only").forEach(x => x.classList.toggle("d-none", user.role !== "admin"));
  $("#loginView").classList.add("d-none");
  $("#appView").classList.remove("d-none");
  render("dashboard");
}

document.addEventListener("click", e => { const b = e.target.closest("[data-page]"); if (b) render(b.dataset.page); });

$("#loginForm").addEventListener("submit", async e => {
  e.preventDefault();
  const btn = e.target.querySelector("button");
  btn.disabled = true;
  try {
    const r = await api("/auth/login", { method: "POST", body: { username: $("#loginUser").value.trim(), password: $("#loginPass").value } });
    $("#loginPass").value = "";
    enterApp(r.user);
  } catch (err) { toast(err.message, "danger"); }
  finally { btn.disabled = false; }
});

$("#logoutBtn").addEventListener("click", async () => {
  try { await api("/auth/logout", { method: "POST", body: {} }); } catch (e) { /* ignore */ }
  location.reload();
});

/* once per second: clock + live timers/costs (estimates; the server calculates the final bill) */
setInterval(() => {
  $("#clock").textContent = new Date().toLocaleString("en-PH", { dateStyle: "medium", timeStyle: "short", timeZone: PH_TZ });
  document.querySelectorAll(".live-cost").forEach(el => { const s = state.live[el.dataset.session]; if (s) el.textContent = money(liveAmount(s)); });
  document.querySelectorAll(".live-dur").forEach(el => { const s = state.live[el.dataset.session]; if (s) el.textContent = clockText(liveSeconds(s)); });
  document.querySelectorAll(".live-rem").forEach(el => { const s = state.live[el.dataset.session]; if (s) { const rem = liveRemaining(s); el.textContent = `${rem <= 0 ? "00:00:00" : clockText(rem)}`; if (rem <= 0 && !window.timeoutRefreshPending) { window.timeoutRefreshPending = true; setTimeout(() => { window.timeoutRefreshPending = false; render(state.page, true); }, 1500); } } });
  if (endCtx && $("#endTotal")) updateEndTotals();
}, 1000);

/* every 10 seconds re-read the database so all screens match the real state (skipped while a form is open) */
setInterval(() => {
  if (!state.user || document.hidden) return;
  if ($("#modal").classList.contains("show")) return;
  const ae = document.activeElement;
  if (ae && $("#content").contains(ae) && ["INPUT", "SELECT", "TEXTAREA"].includes(ae.tagName)) return;
  if (["dashboard", "computers", "sessions", "billing"].includes(state.page)) render(state.page, true);
}, 10000);

/* start: restore the staff login if the browser still has a valid cookie, otherwise show the login screen */
(async function init() {
  try {
    const r = await api("/auth/me");
    if (r.user) enterApp(r.user);
  } catch (e) {
    toast(e.message, "danger");
  }
})();
