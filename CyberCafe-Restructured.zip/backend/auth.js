// Authentication / authorization middleware + first-run account bootstrap.
const bcrypt = require('bcryptjs');
const { pool } = require('./db');
const config = require('./config');
const { AppError } = require('./utils');

// auth()            -> any signed-in, active staff member
// auth('cashier')   -> only cashiers
// auth('admin')     -> only admins
// The user's role and active flag are re-read from MySQL on every request,
// so disabling an account or changing a role takes effect immediately.
function auth(...roles) {
  return async (req, res, next) => {
    try {
      const userId = req.session && req.session.userId;
      if (!userId) throw new AppError(401, 'Please sign in.');
      const [rows] = await pool.query('SELECT id, username, role, is_active FROM users WHERE id = ?', [userId]);
      const u = rows[0];
      if (!u || !u.is_active) {
        await new Promise(resolve => req.session.destroy(resolve));
        throw new AppError(401, 'Your account is not active. Please sign in again.');
      }
      if (roles.length && !roles.includes(u.role)) {
        throw new AppError(403, 'You do not have permission to do this.');
      }
      req.user = { id: u.id, username: u.username, role: u.role };
      next();
    } catch (err) {
      next(err);
    }
  };
}

// Role gate for routes already behind auth(): only('cashier') / only('admin')
const only = (...roles) => (req, res, next) =>
  roles.includes(req.user.role) ? next() : next(new AppError(403, 'You do not have permission to do this.'));

// Creates the starter admin + cashier accounts ONLY when the users table is empty.
async function ensureDefaultUsers() {
  const [rows] = await pool.query('SELECT COUNT(*) AS n FROM users');
  if (rows[0].n > 0) return false;
  const adminHash = await bcrypt.hash(config.defaultAdminPassword, 10);
  const cashierHash = await bcrypt.hash(config.defaultCashierPassword, 10);
  await pool.query(
    'INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?), (?, ?, ?)',
    ['admin', adminHash, 'admin', 'cashier', cashierHash, 'cashier']
  );
  console.warn('[setup] Created starter accounts "admin" and "cashier". Change their passwords after the first login!');
  return true;
}

module.exports = { auth, only, ensureDefaultUsers };
