// Admin-only statistics. Everything is calculated from MySQL - no placeholder numbers.
const express = require('express');
const { pool } = require('../db');
const config = require('../config');
const { wrap } = require('../utils');

const router = express.Router();
const OFF = config.tzOffset; // validated in config.js, safe to inline
const local = col => `CONVERT_TZ(${col}, '+00:00', '${OFF}')`;
const TODAY = `DATE(CONVERT_TZ(UTC_TIMESTAMP(), '+00:00', '${OFF}'))`;

function parseDays(v) {
  const n = parseInt(v, 10);
  return [7, 14, 30, 90].includes(n) ? n : 14;
}

// last N local dates (oldest -> newest) as YYYY-MM-DD strings
async function lastDates(days) {
  const [[{ d }]] = await pool.query(`SELECT DATE_FORMAT(${TODAY}, '%Y-%m-%d') AS d`);
  const base = new Date(`${d}T00:00:00Z`);
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const x = new Date(base.getTime() - i * 86400000);
    out.push(x.toISOString().slice(0, 10));
  }
  return out;
}

router.get('/stats', wrap(async (req, res) => {
  const [pcRows] = await pool.query('SELECT status, COUNT(*) AS n FROM computers GROUP BY status');
  const pc = { total: 0, inUse: 0, available: 0, maintenance: 0, archived: 0 };
  for (const r of pcRows) {
    if (r.status === 'Archived') { pc.archived = r.n; continue; }
    pc.total += r.n;
    if (r.status === 'In Use') pc.inUse = r.n;
    if (r.status === 'Available') pc.available = r.n;
    if (r.status === 'Maintenance') pc.maintenance = r.n;
  }
  const [[rev]] = await pool.query(
    `SELECT COALESCE(SUM(amount), 0) AS total, COUNT(*) AS n,
            COALESCE(SUM(CASE WHEN DATE(${local('transaction_date')}) = ${TODAY} THEN amount END), 0) AS today
       FROM transactions`);
  const [[ses]] = await pool.query(
    `SELECT COUNT(*) AS n FROM sessions WHERE DATE(${local('start_time')}) = ${TODAY}`);
  const [[use]] = await pool.query(
    `SELECT COUNT(*) AS n, COALESCE(SUM(duration_seconds), 0) AS total_s, COALESCE(AVG(duration_seconds), 0) AS avg_s
       FROM sessions WHERE status = 'Completed'`);
  const [[act]] = await pool.query("SELECT COUNT(*) AS n FROM sessions WHERE status = 'Active'");
  res.json({
    todayRevenue: Number(rev.today),
    totalRevenue: Number(rev.total),
    transactionCount: rev.n,
    sessionsToday: ses.n,
    activeSessions: act.n,
    completedSessions: use.n,
    totalUsageSeconds: Number(use.total_s),
    avgSessionSeconds: Math.round(Number(use.avg_s)),
    computers: pc
  });
}));

router.get('/revenue', wrap(async (req, res) => {
  const days = parseDays(req.query.days);
  const dates = await lastDates(days);
  const [rows] = await pool.query(
    `SELECT DATE_FORMAT(${local('transaction_date')}, '%Y-%m-%d') AS d, SUM(amount) AS revenue, COUNT(*) AS n
       FROM transactions
      WHERE DATE(${local('transaction_date')}) >= DATE_SUB(${TODAY}, INTERVAL ? DAY)
      GROUP BY d`, [days - 1]);
  const map = new Map(rows.map(r => [r.d, r]));
  res.json(dates.map(d => ({ date: d, revenue: map.has(d) ? Number(map.get(d).revenue) : 0, transactions: map.has(d) ? map.get(d).n : 0 })));
}));

router.get('/sessions-over-time', wrap(async (req, res) => {
  const days = parseDays(req.query.days);
  const dates = await lastDates(days);
  const [rows] = await pool.query(
    `SELECT DATE_FORMAT(${local('start_time')}, '%Y-%m-%d') AS d, COUNT(*) AS n
       FROM sessions
      WHERE DATE(${local('start_time')}) >= DATE_SUB(${TODAY}, INTERVAL ? DAY)
      GROUP BY d`, [days - 1]);
  const map = new Map(rows.map(r => [r.d, r.n]));
  res.json(dates.map(d => ({ date: d, sessions: map.get(d) || 0 })));
}));

router.get('/computer-usage', wrap(async (req, res) => {
  const [rows] = await pool.query(
    `SELECT c.id, c.computer_name, COUNT(s.id) AS sessions,
            COALESCE(SUM(s.duration_seconds), 0) AS seconds, COALESCE(SUM(s.total_amount), 0) AS billed
       FROM computers c
       LEFT JOIN sessions s ON s.computer_id = c.id AND s.status = 'Completed'
      GROUP BY c.id, c.computer_name
      ORDER BY sessions DESC, seconds DESC, c.computer_name`);
  res.json(rows.map(r => ({
    id: r.id, name: r.computer_name, sessions: r.sessions,
    usageSeconds: Number(r.seconds), billed: Number(r.billed)
  })));
}));

module.exports = router;
