// Staff account management (admin only). Customers have no accounts here.
const express = require('express');
const bcrypt = require('bcryptjs');
const { pool, withTransaction } = require('../db');
const { AppError, wrap, parseId, cleanStr } = require('../utils');

const router = express.Router();

const map = r => ({ id: r.id, username: r.username, role: r.role, isActive: !!r.is_active, createdAt: r.created_at });

function checkPassword(p) {
  if (typeof p !== 'string' || p.length < 8 || p.length > 100) {
    throw new AppError(400, 'Password must be 8 to 100 characters.');
  }
  return p;
}

router.get('/', wrap(async (req, res) => {
  const [rows] = await pool.query('SELECT id, username, role, is_active, created_at FROM users ORDER BY id');
  res.json(rows.map(map));
}));

router.post('/', wrap(async (req, res) => {
  const username = cleanStr(req.body.username, { max: 50, required: true, label: 'Username' }).toLowerCase();
  if (!/^[a-z0-9._-]{3,50}$/.test(username)) throw new AppError(400, 'Username must be 3-50 characters: letters, numbers, . _ -');
  const role = req.body.role;
  if (!['admin', 'cashier'].includes(role)) throw new AppError(400, 'Role must be admin or cashier.');
  const hash = await bcrypt.hash(checkPassword(req.body.password), 10);
  const [r] = await pool.query('INSERT INTO users (username, password_hash, role) VALUES (?, ?, ?)', [username, hash, role]);
  res.status(201).json({ id: r.insertId, username, role, isActive: true });
}));

// Enable/disable an account and/or reset its password
router.patch('/:id', wrap(async (req, res) => {
  const id = parseId(req.params.id, 'user ID');
  const { isActive, password } = req.body;
  if (isActive === undefined && password === undefined) throw new AppError(400, 'Nothing to update.');
  if (isActive !== undefined && typeof isActive !== 'boolean') throw new AppError(400, 'isActive must be true or false.');
  const hash = password !== undefined ? await bcrypt.hash(checkPassword(password), 10) : null;

  await withTransaction(async conn => {
    const [rows] = await conn.query('SELECT id, role, is_active FROM users WHERE id = ? FOR UPDATE', [id]);
    const u = rows[0];
    if (!u) throw new AppError(404, 'User not found.');
    if (isActive === false) {
      if (u.id === req.user.id) throw new AppError(400, 'You cannot disable your own account.');
      if (u.role === 'admin' && u.is_active) {
        const [others] = await conn.query("SELECT COUNT(*) AS n FROM users WHERE role = 'admin' AND is_active = 1 AND id <> ?", [id]);
        if (others[0].n === 0) throw new AppError(400, 'At least one active admin account is required.');
      }
    }
    if (isActive !== undefined) await conn.query('UPDATE users SET is_active = ? WHERE id = ?', [isActive ? 1 : 0, id]);
    if (hash) await conn.query('UPDATE users SET password_hash = ? WHERE id = ?', [hash, id]);
  });
  res.json({ ok: true });
}));

module.exports = router;
