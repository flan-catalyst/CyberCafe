// Compatibility entry point. The actual server and its paths live in backend/server.js.
require('./backend/server');
