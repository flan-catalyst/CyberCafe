const express = require('express');
const bcrypt = require('bcryptjs');
const { pool } = require('../db');
const { AppError, wrap, cleanStr } = require('../utils');

const router = express.Router();

// Simple brute-force protection: 8 failed sign-ins per IP+username per 15 minutes.
const MAX_FAILS = 8;
const WINDOW_MS = 15 * 60 * 1000;
const fails = new Map();
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10); // keeps timing similar for unknown users

router.post('/login', wrap(async (req, res) => {
  const username = cleanStr(req.body.username, { max: 50, required: true, label: 'Username' }).toLowerCase();
  const password = typeof req.body.password === 'string' ? req.body.password : '';
  if (!password) throw new AppError(400, 'Password is required.');

  const key = `${req.ip}|${username}`;
  const rec = fails.get(key);
  if (rec && Date.now() > rec.until) fails.delete(key);
  if (rec && rec.count >= MAX_FAILS && Date.now() <= rec.until) {
    throw new AppError(429, 'Too many failed sign-in attempts. Please wait a few minutes and try again.');
  }

  const [rows] = await pool.query(
    'SELECT id, username, password_hash, role, is_active FROM users WHERE username = ?', [username]);
  const user = rows[0];
  const ok = await bcrypt.compare(password, user ? user.password_hash : DUMMY_HASH);
  if (!user || !ok || !user.is_active) {
    const cur = fails.get(key) || { count: 0, until: Date.now() + WINDOW_MS };
    cur.count += 1;
    fails.set(key, cur);
    throw new AppError(401, 'Invalid username or password.');
  }
  fails.delete(key);

  await new Promise((resolve, reject) => req.session.regenerate(e => (e ? reject(e) : resolve())));
  req.session.userId = user.id;
  res.json({ user: { id: user.id, username: user.username, role: user.role } });
}));

router.post('/logout', (req, res) => {
  req.session.destroy(() => {
    res.clearCookie('cybercafe.sid');
    res.json({ ok: true });
  });
});

router.get('/me', wrap(async (req, res) => {
  if (!req.session.userId) return res.json({ user: null });
  const [rows] = await pool.query('SELECT id, username, role, is_active FROM users WHERE id = ?', [req.session.userId]);
  const u = rows[0];
  if (!u || !u.is_active) return res.json({ user: null });
  res.json({ user: { id: u.id, username: u.username, role: u.role } });
}));

module.exports = router;
