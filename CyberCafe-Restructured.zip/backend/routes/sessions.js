const express = require('express');
const { pool, withTransaction } = require('../db');
const { only } = require('../auth');
const { AppError, wrap, parseId, cleanStr, toCents, rentalCents, SESSION_SELECT, mapSession, getSessionDetail } = require('../utils');

const router = express.Router();

// List sessions (both roles). ?status=Active|Completed  ?q=text  ?limit=200
router.get('/', wrap(async (req, res) => {
  const status = ['Active', 'Completed'].includes(req.query.status) ? req.query.status : null;
  const q = typeof req.query.q === 'string' ? req.query.q.trim().slice(0, 100) : '';
  const limit = Math.min(Math.max(parseInt(req.query.limit, 10) || 200, 1), 500);
  const where = [];
  const params = [];
  if (status) { where.push('s.status = ?'); params.push(status); }
  if (q) {
    const like = `%${q.replace(/[\\%_]/g, m => '\\' + m)}%`;
    where.push(`(CONCAT('SES-', LPAD(s.id, 4, '0')) LIKE ? OR c.computer_name LIKE ? OR CONCAT(cu.first_name, ' ', cu.last_name) LIKE ?
                 OR cu.customer_code LIKE ? OR s.guest_name LIKE ?)`);
    params.push(like, like, like, like, like);
  }
  const [rows] = await pool.query(
    `${SESSION_SELECT} ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ORDER BY s.start_time DESC, s.id DESC LIMIT ?`, [...params, limit]);
  res.json(rows.map(mapSession));
}));

// One session with its service lines and payment (both roles)
router.get('/:id', wrap(async (req, res) => {
  res.json(await getSessionDetail(pool, parseId(req.params.id, 'session ID')));
}));

// START a session (cashier only)
router.post('/start', only('cashier'), wrap(async (req, res) => {
  const computerId = parseId(req.body.computerId, 'computer');
  const type = req.body.customerType;
  if (!['guest', 'existing'].includes(type)) throw new AppError(400, 'Choose Guest or Existing Customer.');

  const timerMode = req.body.timerMode === 'fixed' ? 'fixed' : 'open';
  let durationMinutes = null;
  if (timerMode === 'fixed') {
    durationMinutes = Number(req.body.durationMinutes);
    if (!Number.isInteger(durationMinutes) || durationMinutes < 30 || durationMinutes % 30 !== 0 || durationMinutes > 1440) {
      throw new AppError(400, 'Fixed session time must be a multiple of 30 minutes, from 30 minutes up to 24 hours.');
    }
  }

  let customerId = null;
  let guestName = null;
  if (type === 'existing') {
    customerId = parseId(req.body.customerId, 'customer ID');
  } else {
    guestName = cleanStr(req.body.guestName, { max: 100, label: 'Guest name' });
  }

  const sessionId = await withTransaction(async conn => {
    const [pcs] = await conn.query('SELECT id, computer_name, status, hourly_rate FROM computers WHERE id = ? FOR UPDATE', [computerId]);
    const pc = pcs[0];
    if (!pc) throw new AppError(404, 'Computer not found.');
    if (pc.status === 'Maintenance') throw new AppError(409, `${pc.computer_name} is under maintenance and cannot be used.`);
    if (pc.status === 'Archived') throw new AppError(409, `${pc.computer_name} is archived and cannot be used.`);
    if (pc.status === 'In Use') throw new AppError(409, `${pc.computer_name} is already in use.`);

    if (customerId !== null) {
      const [cu] = await conn.query('SELECT id FROM customers WHERE id = ?', [customerId]);
      if (!cu.length) throw new AppError(400, 'That customer does not exist.');
    }
    const [r] = await conn.query(
      `INSERT INTO sessions (computer_id, customer_id, guest_name, started_by, start_time, timer_mode, duration_limit_seconds, expires_at, hourly_rate, status)
       VALUES (?, ?, ?, ?, UTC_TIMESTAMP(), ?, ?, CASE WHEN ? = 'fixed' THEN DATE_ADD(UTC_TIMESTAMP(), INTERVAL ? MINUTE) ELSE NULL END, ?, 'Active')`,
      [computerId, customerId, guestName, req.user.id, timerMode, timerMode === 'fixed' ? durationMinutes * 60 : null, timerMode, durationMinutes || 0, pc.hourly_rate]);
    await conn.query("UPDATE computers SET status = 'In Use' WHERE id = ?", [computerId]);
    return r.insertId;
  });
  res.status(201).json(await getSessionDetail(pool, sessionId));
}));

function parseServiceLines(v) {
  if (v === undefined || v === null) return [];
  if (!Array.isArray(v) || v.length > 25) throw new AppError(400, 'Invalid services list.');
  return v.map(l => {
    if (!l || typeof l !== 'object') throw new AppError(400, 'Invalid services list.');
    const serviceId = parseId(l.serviceId, 'service');
    const quantity = Number(l.quantity);
    if (!Number.isInteger(quantity) || quantity < 1 || quantity > 1000) {
      throw new AppError(400, 'Service quantity must be a whole number from 1 to 1000.');
    }
    return { serviceId, quantity };
  });
}

// Add a service to an ACTIVE session without stopping the PC timer (cashier only).
router.post('/:id/services', only('cashier'), wrap(async (req, res) => {
  const id = parseId(req.params.id, 'session ID');
  const serviceId = parseId(req.body.serviceId, 'service');
  const quantity = Number(req.body.quantity);
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 1000) {
    throw new AppError(400, 'Service quantity must be a whole number from 1 to 1000.');
  }
  await withTransaction(async conn => {
    const [rows] = await conn.query('SELECT id, status FROM sessions WHERE id = ? FOR UPDATE', [id]);
    if (!rows.length) throw new AppError(404, 'Session not found.');
    if (rows[0].status !== 'Active') throw new AppError(409, 'Services can only be added while the session is active.');
    const [svcs] = await conn.query('SELECT id, price FROM services WHERE id = ? AND is_active = 1', [serviceId]);
    if (!svcs.length) throw new AppError(400, 'That service is not available.');
    await conn.query('INSERT INTO session_services (session_id, service_id, quantity, unit_price) VALUES (?, ?, ?, ?)',
      [id, serviceId, quantity, svcs[0].price]);
    const [sumRows] = await conn.query('SELECT COALESCE(SUM(quantity * unit_price), 0) AS total FROM session_services WHERE session_id = ?', [id]);
    const servicesTotal = Number(sumRows[0].total || 0);
    await conn.query('UPDATE sessions SET services_amount = ?, total_amount = ? WHERE id = ?', [servicesTotal, servicesTotal, id]);
  });
  res.status(201).json(await getSessionDetail(pool, id));
}));

// END a session (cashier only): the SERVER measures the time and computes the bill.
router.post('/:id/end', only('cashier'), wrap(async (req, res) => {
  const id = parseId(req.params.id, 'session ID');
  const lines = parseServiceLines(req.body.services);
  const additionalFee = req.body.additionalFee === '' || req.body.additionalFee === null || req.body.additionalFee === undefined
    ? 0 : Number(req.body.additionalFee);
  if (!Number.isFinite(additionalFee) || additionalFee < 0 || additionalFee > 100000 || Math.round(additionalFee * 100) !== additionalFee * 100) {
    throw new AppError(400, 'Additional fee must be a valid amount with at most 2 decimal places.');
  }
  const additionalFeeNote = additionalFee > 0 ? cleanStr(req.body.additionalFeeNote, { max: 200, required: true, label: 'Additional fee description' }) : null;

  await withTransaction(async conn => {
    const [rows] = await conn.query(
      `SELECT id, computer_id, hourly_rate, status,
              TIMESTAMPDIFF(SECOND, start_time, UTC_TIMESTAMP()) AS secs
         FROM sessions WHERE id = ? FOR UPDATE`, [id]);
    const s = rows[0];
    if (!s) throw new AppError(404, 'Session not found.');
    if (s.status !== 'Active') throw new AppError(409, 'This session has already ended.');

    const insertRows = [];
    if (lines.length) {
      const ids = [...new Set(lines.map(l => l.serviceId))];
      const [svcs] = await conn.query('SELECT id, price FROM services WHERE is_active = 1 AND id IN (?)', [ids]);
      const priceById = new Map(svcs.map(x => [x.id, x.price]));
      for (const l of lines) {
        if (!priceById.has(l.serviceId)) throw new AppError(400, 'One of the selected services is not available.');
        insertRows.push([id, l.serviceId, l.quantity, priceById.get(l.serviceId)]);
      }
    }

    const secs = Math.max(0, s.secs);
    const rentalC = rentalCents(secs, s.hourly_rate);
    if (insertRows.length) {
      await conn.query('INSERT INTO session_services (session_id, service_id, quantity, unit_price) VALUES ?', [insertRows]);
    }
    const [serviceTotals] = await conn.query('SELECT COALESCE(SUM(quantity * unit_price), 0) AS total FROM session_services WHERE session_id = ?', [id]);
    const servicesCents = toCents(serviceTotals[0].total || 0);
    await conn.query(
      `UPDATE sessions
          SET end_time = DATE_ADD(start_time, INTERVAL ? SECOND), duration_seconds = ?,
              rental_amount = ?, services_amount = ?, additional_fee_amount = ?, additional_fee_note = ?,
              total_amount = ?, ended_by = ?, end_reason = 'Timeout', status = 'Completed'
        WHERE id = ?`,
      [secs, secs, rentalC / 100, servicesCents / 100, additionalFee, additionalFeeNote,
       (rentalC + servicesCents + toCents(additionalFee)) / 100, req.user.id, id]);
    await conn.query("UPDATE computers SET status = 'Available' WHERE id = ? AND status = 'In Use'", [s.computer_id]);
  });
  res.json(await getSessionDetail(pool, id));
}));

module.exports = router;
